"""Whole-machine CPU usage from /proc/stat."""


def parse_stat(text):
    """(busy, total) jiffies from the aggregate "cpu" line of /proc/stat."""
    for line in text.splitlines():
        if line.startswith('cpu '):
            v = [int(x) for x in line.split()[1:9]]
            v += [0] * (8 - len(v))
            # user nice system idle iowait irq softirq steal (guest time is already in user/nice)
            total = sum(v)
            return total - v[3] - v[4], total
    return 0, 0


def _read():
    with open('/proc/stat') as f:
        return f.read()


class CpuMeter:
    def __init__(self, read=_read):
        self.read = read
        self.last = parse_stat(self.read())

    def sample(self):
        """Fraction 0..1 of CPU time spent busy since the previous sample."""
        now = parse_stat(self.read())
        busy = now[0] - self.last[0]
        total = now[1] - self.last[1]
        self.last = now
        return min(1.0, max(0.0, busy / total)) if total > 0 else 0.0
