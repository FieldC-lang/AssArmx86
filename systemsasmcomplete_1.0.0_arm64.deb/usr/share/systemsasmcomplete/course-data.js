window.COURSE = [
  {
    "id": "x86-linux",
    "title": "x86-64",
    "blurb": "Registers, arithmetic, branches, memory, and calls, then Linux syscalls and the Win32 convention.",
    "lessons": [
      {
        "id": "x86a-1",
        "title": "Registers",
        "teach": "An x86-64 processor has sixteen general registers: rax, rcx, rdx, rbx, rsp, rbp, rsi, rdi, and r8 through r15. rax is the usual result register. rsp is the stack pointer. rip is the instruction pointer and is not one of those sixteen. Writing eax zeros the top half of rax. al and ax are the low 8 and 16 bits of rax. Linux and Windows use the same registers; they disagree about which ones hold arguments.",
        "code": "mov eax, 1\n; rax is now 1, and the old top half is gone",
        "questions": [
          {
            "q": "Which register is the stack pointer?",
            "choices": [
              "rsp",
              "rip",
              "rax",
              "rflags"
            ],
            "answer": 0,
            "why": "rsp addresses the stack. rip is the instruction pointer."
          },
          {
            "q": "What does writing eax do to the rest of rax?",
            "choices": [
              "It zeros bits 32 through 63",
              "It leaves the top half unchanged",
              "It writes the stack",
              "It sets the carry flag"
            ],
            "answer": 0,
            "why": "A 32-bit write into a general register clears the upper 32 bits."
          },
          {
            "q": "Which name is the low 8 bits of rax?",
            "choices": [
              "al",
              "ah only",
              "r8",
              "rip"
            ],
            "answer": 0,
            "why": "al is bits 0 through 7. ax is the low 16, eax the low 32."
          }
        ]
      },
      {
        "id": "x86a-2",
        "title": "Moving data",
        "teach": "mov copies a value. mov rax, rbx copies rbx into rax and leaves rbx alone. mov rax, 5 writes an immediate. mov rax, [rbx] is a load, not a register copy. lea rax, [rbx+8] computes the address rbx+8 and stores that address, without reading memory. There is no mov from memory to memory; copy through a register.",
        "code": "mov rax, rbx\nlea rcx, [rbx+8]",
        "questions": [
          {
            "q": "What does mov rax, rbx do?",
            "choices": [
              "Copies rbx into rax",
              "Swaps rax and rbx",
              "Adds them",
              "Reads memory at rbx"
            ],
            "answer": 0,
            "why": "mov is a copy into the destination, which is written first in Intel syntax."
          },
          {
            "q": "What does lea rax, [rbx+8] put in rax?",
            "choices": [
              "The address rbx+8",
              "The qword stored at rbx+8",
              "8",
              "rbx unchanged and rax cleared"
            ],
            "answer": 0,
            "why": "lea calculates the address. The brackets do not mean a load for lea."
          },
          {
            "q": "Which transfer is not a single mov?",
            "choices": [
              "Memory to memory",
              "Immediate to register",
              "Register to register",
              "Register to memory"
            ],
            "answer": 0,
            "why": "mov can have one memory operand, not two."
          }
        ]
      },
      {
        "id": "x86a-3",
        "title": "Arithmetic",
        "teach": "add rax, rbx adds rbx into rax. sub rax, 1 subtracts from rax. inc and dec add or subtract one. imul rax, rbx multiplies signed values and writes rax. The destination is the first operand in this syntax. add and sub update the flags. A later conditional jump reads those flags, so the arithmetic itself is the comparison if you use the flag-setting form.",
        "code": "mov rax, 40\nadd rax, 2\nsub rax, 1",
        "questions": [
          {
            "q": "After mov rax, 40 and add rax, 2, what is rax?",
            "choices": [
              "42",
              "40",
              "2",
              "80"
            ],
            "answer": 0,
            "why": "add writes the sum back to the first operand."
          },
          {
            "q": "Which instruction multiplies rax by rbx and stores the product in rax?",
            "choices": [
              "imul rax, rbx",
              "add rax, rbx",
              "lea rax, [rbx]",
              "mov rax, rbx"
            ],
            "answer": 0,
            "why": "imul is the multiply. add would only add."
          },
          {
            "q": "Which pair updates the flags as a side effect?",
            "choices": [
              "add and sub",
              "lea and mov",
              "mov alone",
              "A label"
            ],
            "answer": 0,
            "why": "add and sub write rflags. lea and plain mov do not."
          }
        ]
      },
      {
        "id": "x86a-4",
        "title": "Compare and branch",
        "teach": "cmp rax, rbx subtracts rbx from rax, sets the flags, and throws the difference away. je jumps if the operands were equal. jne jumps if they were not. jl and jg are signed less and greater. jb and ja are unsigned. A conditional jump reads the flags from the immediately relevant cmp or arithmetic; do not put a flag-clobbering instruction between the compare and the jump.",
        "code": "cmp rax, rbx\nje equal\njl less\njmp greater_or_other",
        "questions": [
          {
            "q": "What does cmp change?",
            "choices": [
              "The flags only",
              "rax",
              "rbx",
              "Memory"
            ],
            "answer": 0,
            "why": "cmp is a subtraction used only for the flags."
          },
          {
            "q": "Which jump is taken when a signed rax is less than rbx?",
            "choices": [
              "jl",
              "jb",
              "ja",
              "je"
            ],
            "answer": 0,
            "why": "jl is signed less-than. jb is the unsigned below."
          },
          {
            "q": "Why must the jump follow the cmp with no unrelated instruction between them?",
            "choices": [
              "That instruction could overwrite the flags cmp just set",
              "Jumps cannot be conditional",
              "cmp writes rax",
              "The assembler deletes flags"
            ],
            "answer": 0,
            "why": "je and the other jcc forms read rflags as they stand."
          }
        ]
      },
      {
        "id": "x86a-5",
        "title": "Loops",
        "teach": "A counted loop keeps the trip count in a register, does the body, then decrements and jumps while the count is not zero. dec rcx sets the zero flag, so jnz top branches back until rcx becomes 0. The loop instruction is a shorthand that decrements rcx and branches while rcx is not zero. The body must not destroy the counter unless that is intentional. A test at the top, cmp then je past the body, is how a loop runs zero times.",
        "code": "mov rcx, 3\ntop:\nadd rax, rbx\ndec rcx\njnz top",
        "questions": [
          {
            "q": "dec rcx / jnz top falls through when rcx becomes what?",
            "choices": [
              "0",
              "1",
              "-1",
              "The value in rax"
            ],
            "answer": 0,
            "why": "dec sets ZF when the result is zero, and jnz stops branching then."
          },
          {
            "q": "What does the loop instruction use as its counter?",
            "choices": [
              "rcx",
              "rax",
              "rsp",
              "rip"
            ],
            "answer": 0,
            "why": "loop decrements rcx, or ecx in 32-bit code, and branches if it is not zero."
          },
          {
            "q": "How do you write a loop that does nothing when the count starts at zero?",
            "choices": [
              "Compare the count before the body and jump over it",
              "Use dec after the body with no test",
              "Put the count in rip",
              "Call ret"
            ],
            "answer": 0,
            "why": "A test at the top is a while. A test only at the bottom runs once first."
          }
        ]
      },
      {
        "id": "x86a-6",
        "title": "Memory",
        "teach": "mov rax, [rbx] loads the qword at the address in rbx. mov [rbx], rax stores rax there. The size matters: byte ptr, word ptr, dword ptr, and qword ptr select 1, 2, 4, or 8 bytes. [rbx+rcx*8+16] is a scaled index: base rbx, index rcx, scale 8, displacement 16. That scale is how a qword array is indexed. The address must be valid for the process; the instruction does not allocate memory.",
        "code": "mov rax, [rbx+rcx*8]\nmov dword ptr [rdx], eax",
        "questions": [
          {
            "q": "What does mov rax, [rbx] do?",
            "choices": [
              "Loads eight bytes from the address in rbx",
              "Copies rbx into rax",
              "Stores rax at rbx",
              "Pushes rbx"
            ],
            "answer": 0,
            "why": "Brackets on mov are a memory operand. lea would have taken the address instead."
          },
          {
            "q": "In [rbx+rcx*8], what is the 8?",
            "choices": [
              "The scale, in bytes per element",
              "A syscall number",
              "The segment",
              "The stack size"
            ],
            "answer": 0,
            "why": "Scale multiplies the index. 8 selects a qword element."
          },
          {
            "q": "Which size is a dword?",
            "choices": [
              "4 bytes",
              "8 bytes",
              "1 byte",
              "16 bytes"
            ],
            "answer": 0,
            "why": "Byte, word, dword, qword are 1, 2, 4, and 8 bytes."
          }
        ]
      },
      {
        "id": "x86a-7",
        "title": "Stack, call, and return",
        "teach": "The stack grows down. push rax subtracts 8 from rsp and writes rax there. pop rax reads it back and adds 8. call pushes the return address and jumps. ret pops that address into rip. A frame often saves rbp, then sets rbp to rsp, so local slots are addressed from rbp. Every push needs a matching pop before ret, or ret will jump to whatever was left on the stack. Windows x64 also requires 32 bytes of shadow space; Linux x86-64 does not.",
        "code": "push rbp\nmov rbp, rsp\ncall work\npop rbp\nret",
        "questions": [
          {
            "q": "Which way does the stack grow?",
            "choices": [
              "Toward lower addresses",
              "Toward higher addresses",
              "It does not move rsp",
              "Only on Windows"
            ],
            "answer": 0,
            "why": "push subtracts from rsp. pop adds it back."
          },
          {
            "q": "What does call push?",
            "choices": [
              "The address of the following instruction",
              "rbp only",
              "The syscall number",
              "rax"
            ],
            "answer": 0,
            "why": "ret pops that address and continues after the call."
          },
          {
            "q": "Which platform's x64 calling convention demands 32 bytes of shadow space?",
            "choices": [
              "Windows",
              "Linux",
              "MS-DOS",
              "Both Linux and DOS"
            ],
            "answer": 0,
            "why": "The Microsoft x64 ABI reserves four home slots. The System V AMD64 ABI does not."
          }
        ]
      },
      {
        "id": "x86a-8",
        "title": "Logic and shifts",
        "teach": "and, or, and xor work bit by bit. xor rax, rax is the usual way to zero rax, and it sets the zero flag. not is a bitwise complement. shl and shr are logical shifts. sar is an arithmetic right shift that keeps the sign bit. A shift of one can multiply or divide by two when you mean that and account for the bits that fall off. test rax, rax sets the flags from rax without changing it, which is the usual zero check.",
        "code": "xor rax, rax\nshl rbx, 1\ntest rcx, rcx\njz empty",
        "questions": [
          {
            "q": "What is a common way to set rax to zero?",
            "choices": [
              "xor rax, rax",
              "not rax",
              "shr rax, 0",
              "push rax"
            ],
            "answer": 0,
            "why": "xor of a register with itself clears every bit."
          },
          {
            "q": "Which right shift preserves the sign bit?",
            "choices": [
              "sar",
              "shr",
              "shl",
              "xor"
            ],
            "answer": 0,
            "why": "sar is arithmetic. shr fills the top with zero."
          },
          {
            "q": "What does test rcx, rcx change?",
            "choices": [
              "The flags, not rcx",
              "rcx, clearing it",
              "Memory at rcx",
              "rsp"
            ],
            "answer": 0,
            "why": "test is an and that only writes flags. The register stays as it was."
          }
        ]
      },
      {
        "id": "x86l-1",
        "title": "The syscall instruction",
        "teach": "On x86-64 Linux a user program enters the kernel with the syscall instruction, not with int 0x80. rax holds the syscall number. The arguments go in rdi, rsi, rdx, r10, r8, r9, in that order. rcx is not an argument: the processor uses rcx to save the return address, so the fourth argument is r10. The result comes back in rax. A value from -4095 to -1 is a negative errno.",
        "code": "mov rax, 1\nmov rdi, 1\nmov rsi, msg\nmov rdx, len\nsyscall",
        "questions": [
          {
            "q": "Which instruction do x86-64 Linux programs use to enter the kernel?",
            "choices": [
              "syscall",
              "svc #0",
              "ecall",
              "int 21h"
            ],
            "answer": 0,
            "why": "syscall is the x86-64 entry. svc is ARM64, ecall is RISC-V, and int 21h is DOS."
          },
          {
            "q": "Which register holds the syscall number?",
            "choices": [
              "rax",
              "rdi",
              "rcx",
              "r10"
            ],
            "answer": 0,
            "why": "rax is the number. rdi is the first argument."
          },
          {
            "q": "Why is the fourth argument in r10 rather than rcx?",
            "choices": [
              "syscall uses rcx internally, so the ABI moved that argument to r10",
              "rcx cannot hold a pointer",
              "Linux ignores the fourth argument",
              "r10 is the stack pointer"
            ],
            "answer": 0,
            "why": "The syscall instruction saves the return RIP in rcx. The Linux ABI therefore uses r10 for arg4."
          }
        ]
      },
      {
        "id": "x86l-2",
        "title": "write and exit",
        "teach": "write is syscall 1. rdi is the file descriptor, rsi is the buffer, and rdx is the byte count. File descriptor 1 is standard output. exit is syscall 60. rdi is the status code. exit does not return to the next instruction when it succeeds. A short program writes its message, then exits with status 0.",
        "code": "mov rax, 1\nmov rdi, 1\nmov rsi, msg\nmov rdx, msg_len\nsyscall\nmov rax, 60\nxor rdi, rdi\nsyscall",
        "questions": [
          {
            "q": "What is the x86-64 Linux number for write?",
            "choices": [
              "1",
              "4",
              "64",
              "60"
            ],
            "answer": 0,
            "why": "On x86-64, write is 1. The i386 int 0x80 number is 4, and the generic ARM64/RISC-V number is 64."
          },
          {
            "q": "A write to standard output puts which value in rdi?",
            "choices": [
              "1, the stdout descriptor",
              "0, the stdin descriptor",
              "60, the exit number",
              "The byte count"
            ],
            "answer": 0,
            "why": "rdi is arg1, the file descriptor. stdout is 1. The count belongs in rdx."
          },
          {
            "q": "Which pair exits with status 0?",
            "choices": [
              "rax = 60 and rdi = 0",
              "rax = 1 and rdi = 0",
              "rax = 60 and rsi = 0",
              "rax = 4 and rbx = 0"
            ],
            "answer": 0,
            "why": "60 is exit. rdi is the status. rsi is not an exit argument."
          }
        ]
      },
      {
        "id": "x86l-3",
        "title": "read, open, and errno",
        "teach": "read is syscall 0. open is syscall 2. For open, rdi is the path pointer, rsi is the flags, and rdx is the mode used when creating a file. O_RDONLY is 0. A non-negative rax is a file descriptor or a byte count. A rax in -1 through -4095 is -errno, so -2 means ENOENT. Programs that want a stable API usually call the libc wrappers read, write, and open, which turn that negative rax into -1 and set errno.",
        "code": "mov rax, 2\nmov rdi, path\nxor rsi, rsi\nsyscall\ncmp rax, 0\njl failed",
        "questions": [
          {
            "q": "open returns -2 in rax. What does that mean?",
            "choices": [
              "The call failed with errno 2 (ENOENT)",
              "The new descriptor is 2",
              "Two bytes were read",
              "The path was opened twice"
            ],
            "answer": 0,
            "why": "Negative returns from -1 to -4095 are -errno. -2 is ENOENT, not a descriptor."
          },
          {
            "q": "Which register holds the flags argument to open?",
            "choices": [
              "rsi",
              "rdi",
              "rax",
              "r10"
            ],
            "answer": 0,
            "why": "rdi is the path, rsi is the flags, rdx is the mode."
          },
          {
            "q": "Why do most programs call libc read instead of the syscall instruction?",
            "choices": [
              "libc turns a negative errno into the usual -1 return and an errno value",
              "The syscall instruction cannot read files",
              "libc uses a different kernel",
              "read has no syscall number"
            ],
            "answer": 0,
            "why": "The raw ABI returns -errno in rax. libc is the stable wrapper C programs are written against."
          }
        ]
      },
      {
        "id": "x86l-4",
        "title": "i386 int 0x80",
        "teach": "32-bit Linux uses int 0x80. eax is the number. Arguments go in ebx, ecx, edx, esi, edi, ebp. The numbers are not the x86-64 numbers: write is 4, read is 3, and exit is 1. A 64-bit kernel still accepts int 0x80 from a 32-bit process, but new 64-bit code should use syscall. Mixing the two numbering schemes is a common bug.",
        "code": "mov eax, 4\nmov ebx, 1\nmov ecx, msg\nmov edx, len\nint 0x80",
        "questions": [
          {
            "q": "Under int 0x80, which register holds the syscall number?",
            "choices": [
              "eax",
              "rax",
              "ebx",
              "x8"
            ],
            "answer": 0,
            "why": "The i386 ABI uses eax. rax is the 64-bit register name used with syscall."
          },
          {
            "q": "What is the i386 number for write?",
            "choices": [
              "4",
              "1",
              "64",
              "60"
            ],
            "answer": 0,
            "why": "i386 write is 4. x86-64 write is 1."
          },
          {
            "q": "A 32-bit program puts the buffer pointer for write in which register?",
            "choices": [
              "ecx",
              "ebx",
              "rsi",
              "rdx"
            ],
            "answer": 0,
            "why": "ebx is the descriptor, ecx is the buffer, edx is the length."
          }
        ]
      },
      {
        "id": "x86w-1",
        "title": "Call kernel32, not syscall",
        "teach": "A normal Windows program does not put a number in rax and execute syscall. It calls exported functions such as WriteFile and ExitProcess in kernel32.dll. Those functions live in ntdll's syscall stubs, and the numbers behind the stubs change between Windows builds. The stable contract is the documented Win32 function, its arguments, and GetLastError. Hard-coding an NT number ties the program to one kernel build.",
        "code": "extern ExitProcess\ncall ExitProcess",
        "questions": [
          {
            "q": "What should an ordinary Windows application call to exit?",
            "choices": [
              "ExitProcess in kernel32",
              "syscall number 60",
              "int 21h with AH=4Ch",
              "ecall with a7=93"
            ],
            "answer": 0,
            "why": "ExitProcess is the Win32 API. 60 and 93 are Linux numbers. int 21h is DOS."
          },
          {
            "q": "Why are raw NT syscall numbers a poor API for applications?",
            "choices": [
              "Microsoft changes them between builds; kernel32 is the stable surface",
              "Windows has no kernel",
              "kernel32 cannot return errors",
              "WriteFile is only a DOS interrupt"
            ],
            "answer": 0,
            "why": "The supported entry is the DLL export. The syscall stub underneath is an OS internal."
          },
          {
            "q": "After WriteFile returns FALSE, where does a Win32 program look for the reason?",
            "choices": [
              "GetLastError",
              "rax as -errno",
              "AH",
              "a7"
            ],
            "answer": 0,
            "why": "Win32 reports failure with a FALSE return and a separate last-error code."
          }
        ]
      },
      {
        "id": "x86w-2",
        "title": "The x64 calling convention",
        "teach": "64-bit Windows passes the first four integer arguments in rcx, rdx, r8, and r9. Further arguments go on the stack. The caller reserves 32 bytes of shadow space and keeps RSP 16-byte aligned at the call. The caller pops stack arguments. The return value is in rax. WriteFile's handle is therefore rcx, the buffer is rdx, the count is r8, and the pointer that receives the byte count is r9.",
        "code": "sub rsp, 40\nmov rcx, handle\nmov rdx, buffer\nmov r8d, count\nmov r9, bytes_written\nmov qword [rsp+32], 0\ncall WriteFile\nadd rsp, 40",
        "questions": [
          {
            "q": "WriteFile's HANDLE argument belongs in which register?",
            "choices": [
              "rcx",
              "rdi",
              "rax",
              "r10"
            ],
            "answer": 0,
            "why": "Windows x64 arg1 is rcx. rdi is the Linux syscall arg1."
          },
          {
            "q": "Who removes stack arguments after a Win64 call?",
            "choices": [
              "The caller",
              "The callee, as in stdcall",
              "The kernel",
              "Nobody"
            ],
            "answer": 0,
            "why": "The Microsoft x64 convention is caller-cleanup, unlike 32-bit stdcall."
          },
          {
            "q": "How much shadow space does the caller reserve?",
            "choices": [
              "32 bytes",
              "0 bytes",
              "8 bytes",
              "320 bytes"
            ],
            "answer": 0,
            "why": "Four argument slots, 8 bytes each, even when the arguments are already in registers."
          }
        ]
      },
      {
        "id": "x86w-3",
        "title": "32-bit stdcall",
        "teach": "32-bit Win32 uses stdcall. Arguments are pushed right to left, so the last argument is pushed first and the first argument is the last push before the call. The callee removes the arguments. EAX holds the return value. WriteFile has five 4-byte arguments, so it cleans 20 bytes off the stack. This is the convention Windows 95 Win32 programs used, and it is still the convention for 32-bit Windows binaries.",
        "code": "push 0\npush offset bytes_written\npush count\npush offset buffer\npush handle\ncall WriteFile",
        "questions": [
          {
            "q": "In the stdcall snippet, which value is pushed last, immediately before call WriteFile?",
            "choices": [
              "The HANDLE",
              "The overlapped pointer",
              "The byte count",
              "The return address"
            ],
            "answer": 0,
            "why": "Right-to-left order means the first parameter, the handle, is closest to the call."
          },
          {
            "q": "How many bytes does a 32-bit WriteFile remove from the stack?",
            "choices": [
              "20",
              "32",
              "4",
              "0"
            ],
            "answer": 0,
            "why": "Five dword parameters, and stdcall makes the callee clean them up."
          },
          {
            "q": "Where is the BOOL result?",
            "choices": [
              "EAX",
              "RAX as -errno",
              "AH",
              "ECX"
            ],
            "answer": 0,
            "why": "32-bit Win32 returns integer results in EAX."
          }
        ]
      }
    ]
  },
  {
    "id": "arm64-linux",
    "title": "ARM64",
    "blurb": "The instruction set, then Linux svc and the Windows ARM64 calling convention.",
    "lessons": [
      {
        "id": "a64a-1",
        "title": "Registers",
        "teach": "ARM64 has 31 general registers, x0 through x30, plus the stack pointer sp and the zero register xzr. x30 is the link register. x0 through x7 carry arguments and x0 carries the result for both Linux calls and Windows calls. Writing a w register, such as w0, writes the low 32 bits and zeros the top half of x0. sp is a restricted register: many arithmetic forms use the zero register instead of sp.",
        "code": "mov w0, w1\n; the top half of x0 becomes zero",
        "questions": [
          {
            "q": "Which register holds a function's return address?",
            "choices": [
              "x30",
              "x0",
              "xzr",
              "sp"
            ],
            "answer": 0,
            "why": "bl writes the return address to x30. ret jumps through x30."
          },
          {
            "q": "What does writing w0 do to x0?",
            "choices": [
              "It zeros bits 32 through 63",
              "It leaves the top half unchanged",
              "It pushes x0",
              "It sets x30"
            ],
            "answer": 0,
            "why": "A 32-bit view write clears the upper half of the 64-bit register."
          },
          {
            "q": "Which register reads as zero and discards writes?",
            "choices": [
              "xzr",
              "x0",
              "x30",
              "sp"
            ],
            "answer": 0,
            "why": "xzr is the zero register. It is not a 32nd general file slot you can keep a value in."
          }
        ]
      },
      {
        "id": "a64a-2",
        "title": "Moving data",
        "teach": "mov x0, x1 copies a register. mov x0, #42 writes a small immediate. Wider constants are built with movz and movk, which plant 16-bit pieces. orr x0, xzr, x1 is the underlying copy from x1, because orring with zero keeps x1. There is no instruction that copies memory to memory in one step. A load is ldr and a store is str; mov does not take a memory operand.",
        "code": "mov x0, #42\nmovz x1, #0x1234, lsl #16\nmovk x1, #0x5678",
        "questions": [
          {
            "q": "Which instruction copies x1 into x0?",
            "choices": [
              "mov x0, x1",
              "ldr x0, [x1]",
              "str x0, [x1]",
              "svc #0"
            ],
            "answer": 0,
            "why": "mov between x registers does not touch memory. ldr would load from the address in x1."
          },
          {
            "q": "What do movz and movk build?",
            "choices": [
              "A wide immediate, 16 bits at a time",
              "A stack frame",
              "A syscall",
              "A branch"
            ],
            "answer": 0,
            "why": "movz plants a chunk and clears the rest. movk plants a chunk and leaves the other bits."
          },
          {
            "q": "orr x0, xzr, x1 is equivalent to which copy?",
            "choices": [
              "mov x0, x1",
              "mov x0, #0",
              "ldr x0, [x1]",
              "add x0, x1, x1"
            ],
            "answer": 0,
            "why": "Orring with the zero register keeps every bit of x1."
          }
        ]
      },
      {
        "id": "a64a-3",
        "title": "Arithmetic",
        "teach": "add x0, x1, x2 writes x1+x2 to x0 and does not change x1 or x2. Three-operand form is normal: the destination is separate from the sources. add x0, x0, #1 is the increment. sub subtracts. mul x0, x1, x2 multiplies. adds and subs are the forms that also update the condition flags. A plain add does not, so a later branch will not see it.",
        "code": "add x0, x1, x2\nsubs x3, x3, #1",
        "questions": [
          {
            "q": "What does add x0, x1, x2 write?",
            "choices": [
              "x1+x2 into x0",
              "x0+x1 into x2",
              "The sum into x30",
              "Memory"
            ],
            "answer": 0,
            "why": "The first register is the destination. The sources stay put."
          },
          {
            "q": "Which form updates the condition flags?",
            "choices": [
              "subs",
              "add",
              "mov",
              "mul"
            ],
            "answer": 0,
            "why": "The s suffix means the instruction sets flags. add without s does not."
          },
          {
            "q": "How do you add one to x0?",
            "choices": [
              "add x0, x0, #1",
              "mov x0, #1",
              "svc #0",
              "ret"
            ],
            "answer": 0,
            "why": "Use x0 as both a source and the destination, plus the immediate 1."
          }
        ]
      },
      {
        "id": "a64a-4",
        "title": "Compare and branch",
        "teach": "cmp x0, x1 is subs xzr, x0, x1: it sets flags and throws the result away. b.eq branches if the operands were equal, b.ne if they were not, b.gt and b.lt for signed order, b.hi and b.lo for unsigned. b is unconditional. The condition is a suffix on b, and it reads the flags from the cmp. A flag-setting instruction in between would replace those flags.",
        "code": "cmp x0, x1\nb.eq same\nb.lt less\nb greater",
        "questions": [
          {
            "q": "cmp x0, x1 is which operation?",
            "choices": [
              "A subtract into the zero register that sets flags",
              "A copy of x0 into x1",
              "A load",
              "A call"
            ],
            "answer": 0,
            "why": "cmp is subs with xzr as the destination."
          },
          {
            "q": "Which branch is signed less-than?",
            "choices": [
              "b.lt",
              "b.lo",
              "b.eq",
              "b.hi"
            ],
            "answer": 0,
            "why": "lt is signed. lo is unsigned lower."
          },
          {
            "q": "Which branch is taken every time?",
            "choices": [
              "b",
              "b.eq",
              "b.ne",
              "b.gt"
            ],
            "answer": 0,
            "why": "b has no condition. The dotted forms are conditional."
          }
        ]
      },
      {
        "id": "a64a-5",
        "title": "Loops",
        "teach": "A counted loop keeps the remaining trips in a register. subs x1, x1, #1 sets the flags, and b.ne top goes back while the result is not zero. That is the same shape as dec/jnz on x86. Put the test before the body when a zero count must skip the work. The register used as the counter must survive the body, or the test is meaningless.",
        "code": "mov x1, #3\ntop:\nadd x0, x0, x2\nsubs x1, x1, #1\nb.ne top",
        "questions": [
          {
            "q": "b.ne after subs x1, x1, #1 stops when x1 becomes what?",
            "choices": [
              "0",
              "1",
              "The value in x0",
              "x30"
            ],
            "answer": 0,
            "why": "subs sets the zero flag when x1 hits 0, so b.ne falls through."
          },
          {
            "q": "Which suffix both subtracts and sets flags?",
            "choices": [
              "subs",
              "sub",
              "mov",
              "b"
            ],
            "answer": 0,
            "why": "sub writes the result only. subs also updates the flags the branch reads."
          },
          {
            "q": "Where does a zero-trip loop put its test?",
            "choices": [
              "Before the body",
              "Only after the first trip",
              "In x30",
              "In the literal pool"
            ],
            "answer": 0,
            "why": "A top test can skip the body. A bottom test has already run it."
          }
        ]
      },
      {
        "id": "a64a-6",
        "title": "Memory",
        "teach": "ldr x0, [x1] loads eight bytes from the address in x1. str x0, [x1] stores them. ldr w0, [x1] loads four bytes into w0 and zeros the top of x0. [x1, #16] adds a displacement. [x1, x2, lsl #3] scales x2 by 8 and adds it to x1, which indexes a qword array. The address has to be mapped. ldr does not allocate the page.",
        "code": "ldr x0, [x1, x2, lsl #3]\nstr x0, [x1, #16]",
        "questions": [
          {
            "q": "What does ldr x0, [x1] do?",
            "choices": [
              "Loads eight bytes from the address in x1",
              "Copies x1 into x0",
              "Stores x0",
              "Pushes x1"
            ],
            "answer": 0,
            "why": "ldr is the load. mov would be the register copy."
          },
          {
            "q": "What does lsl #3 do in [x1, x2, lsl #3]?",
            "choices": [
              "Multiplies the index by 8",
              "Multiplies the index by 3",
              "Shifts the base",
              "Calls the kernel"
            ],
            "answer": 0,
            "why": "A shift of 3 is times 8, the size of a qword."
          },
          {
            "q": "ldr w0, [x1] does what to the top half of x0?",
            "choices": [
              "Zeros it",
              "Leaves it unchanged",
              "Sets it to all ones",
              "Writes it to memory"
            ],
            "answer": 0,
            "why": "A 32-bit load into wn clears the upper half of xn."
          }
        ]
      },
      {
        "id": "a64a-7",
        "title": "Stack, call, and return",
        "teach": "bl label writes the return address to x30 and branches. ret jumps to x30. The stack grows down, and sp must stay 16-byte aligned at a call. stp x29, x30, [sp, #-16]! saves the frame pointer and the link in one store and updates sp. ldp restores them. If a function calls another function, it must save x30 first, or the inner bl will overwrite the return address.",
        "code": "stp x29, x30, [sp, #-16]!\nmov x29, sp\nbl work\nldp x29, x30, [sp], #16\nret",
        "questions": [
          {
            "q": "Where does bl store the return address?",
            "choices": [
              "x30",
              "x0",
              "sp",
              "xzr"
            ],
            "answer": 0,
            "why": "x30 is the link register. ret reads it."
          },
          {
            "q": "Why save x30 before a nested bl?",
            "choices": [
              "The inner bl overwrites x30",
              "x30 is the stack pointer",
              "bl clears x0",
              "The kernel requires x8"
            ],
            "answer": 0,
            "why": "There is one link register. The caller's return address has to be on the stack during the inner call."
          },
          {
            "q": "Which way does sp move on a push-style stp with #-16?",
            "choices": [
              "Down, to a lower address",
              "Up",
              "It does not move",
              "Into x30"
            ],
            "answer": 0,
            "why": "The pre-index #-16 allocates the slot by decreasing sp."
          }
        ]
      },
      {
        "id": "a64a-8",
        "title": "Logic and shifts",
        "teach": "and, orr, and eor are bitwise. mvn is the bitwise not, written as an orn with the zero register in many encodings. lsl, lsr, and asr are left, logical right, and arithmetic right shifts. A left shift of one multiplies by two until the bits overflow. ands sets the flags, which is how you test a bit and then branch. eor x0, x0, x0 clears x0.",
        "code": "eor x0, x0, x0\nlsl x1, x1, #1\nands xzr, x2, #1\nb.eq even",
        "questions": [
          {
            "q": "How do you clear x0 with a logical instruction?",
            "choices": [
              "eor x0, x0, x0",
              "orr x0, x0, x0",
              "lsl x0, x0, #0",
              "ldr x0, [sp]"
            ],
            "answer": 0,
            "why": "Exclusive-or of a value with itself is zero."
          },
          {
            "q": "Which shift keeps the sign bit on the way right?",
            "choices": [
              "asr",
              "lsr",
              "lsl",
              "eor"
            ],
            "answer": 0,
            "why": "asr is arithmetic. lsr inserts zeros at the top."
          },
          {
            "q": "ands xzr, x2, #1 is useful because it does what?",
            "choices": [
              "Sets flags from the low bit without keeping the result",
              "Stores x2",
              "Calls write",
              "Adds 1"
            ],
            "answer": 0,
            "why": "The result is discarded in xzr, and the flags remain for b.eq."
          }
        ]
      },
      {
        "id": "a64l-1",
        "title": "svc and x8",
        "teach": "ARM64 Linux enters the kernel with svc #0. The immediate is zero; the syscall number is in x8, not in the immediate. Arguments go in x0, x1, x2, x3, x4, and x5. The result comes back in x0. As on other Linux ports, a value from -4095 to -1 is -errno. x30 is the link register and is not a syscall argument.",
        "code": "mov x8, #64\nmov x0, #1\nldr x1, =msg\nmov x2, #len\nsvc #0",
        "questions": [
          {
            "q": "Which instruction enters the kernel on ARM64 Linux?",
            "choices": [
              "svc #0",
              "syscall",
              "ecall",
              "int 0x80"
            ],
            "answer": 0,
            "why": "svc is the ARM supervisor call. The Linux number still lives in x8."
          },
          {
            "q": "Which register holds the syscall number?",
            "choices": [
              "x8",
              "x0",
              "x7",
              "rax"
            ],
            "answer": 0,
            "why": "x0 is the first argument and the return value. x8 is the number."
          },
          {
            "q": "What does an x0 result of -13 mean?",
            "choices": [
              "The call failed with errno 13",
              "Thirteen bytes were written",
              "The descriptor is 13",
              "svc was given an immediate of 13"
            ],
            "answer": 0,
            "why": "Linux returns -errno in the result register. -13 is EACCES."
          }
        ]
      },
      {
        "id": "a64l-2",
        "title": "write and exit",
        "teach": "ARM64 uses the generic syscall table, not the x86-64 numbers. write is 64. exit is 93, and exit_group is 94. For write, x0 is the file descriptor, x1 is the buffer, and x2 is the count. For exit, x0 is the status. Learning the x86-64 number 1 for write and then using it in x8 on ARM64 calls a different kernel service.",
        "code": "mov x8, #64\nmov x0, #1\nmov x1, x19\nmov x2, x20\nsvc #0\nmov x8, #93\nmov x0, #0\nsvc #0",
        "questions": [
          {
            "q": "What is the ARM64 Linux number for write?",
            "choices": [
              "64",
              "1",
              "4",
              "93"
            ],
            "answer": 0,
            "why": "The generic table uses 64 for write. x86-64 uses 1."
          },
          {
            "q": "Which registers does write use for descriptor, buffer, and count?",
            "choices": [
              "x0, x1, x2",
              "x8, x0, x1",
              "rdi, rsi, rdx",
              "a7, a0, a1"
            ],
            "answer": 0,
            "why": "x8 is only the number. The first three arguments are x0, x1, and x2."
          },
          {
            "q": "Which number exits the process?",
            "choices": [
              "93 in x8",
              "60 in x8",
              "1 in x0",
              "64 in x8"
            ],
            "answer": 0,
            "why": "exit is 93 on the generic table. 60 is the x86-64 exit number."
          }
        ]
      },
      {
        "id": "a64l-3",
        "title": "libc on ARM64",
        "teach": "The AAPCS64 calling convention used by C puts the first arguments in x0 through x7, and the return value in x0. That lines up with the syscall argument registers, but a C call to write still goes to libc, which moves the arguments into place and sets x8. A compiler calling write(1, buf, len) is not required to emit svc itself. The libc wrapper is the portable surface; the svc sequence is what you write in assembly when you are not linking that wrapper.",
        "code": "mov x0, #1\nmov x1, x19\nmov x2, x20\nbl write",
        "questions": [
          {
            "q": "A C call to write on ARM64 puts the file descriptor in which register?",
            "choices": [
              "x0",
              "x8",
              "x30",
              "sp"
            ],
            "answer": 0,
            "why": "AAPCS64 arg1 is x0. x8 becomes the syscall number only inside the libc stub or your own assembly."
          },
          {
            "q": "What does bl write do?",
            "choices": [
              "It calls the libc wrapper, which will issue svc",
              "It enters the kernel immediately",
              "It is the DOS print-string call",
              "It stores x8"
            ],
            "answer": 0,
            "why": "bl is a normal function call. The wrapper, not the call site, performs svc."
          },
          {
            "q": "Which register is the link register, not a syscall argument?",
            "choices": [
              "x30",
              "x0",
              "x1",
              "x8"
            ],
            "answer": 0,
            "why": "x30 holds the return address for bl and ret."
          }
        ]
      },
      {
        "id": "a64w-1",
        "title": "Win32 on ARM64",
        "teach": "Windows on ARM64 still wants applications to call kernel32 and the other documented DLLs. The processor is ARM64, so the calling convention is the Windows ARM64 convention: integer arguments in x0 through x7, return value in x0, and x8 available as indirect-result scratch rather than as a Linux syscall number. Do not put the Linux write number 64 in x8 and execute svc from an application. That is the Linux ABI, and the NT numbers behind ntdll are versioned internals.",
        "code": "mov x0, x19\nmov x1, x20\nmov w2, w21\nmov x3, x22\nbl WriteFile",
        "questions": [
          {
            "q": "Where does an ARM64 Windows call to WriteFile put the HANDLE?",
            "choices": [
              "x0",
              "x8",
              "rcx",
              "rax"
            ],
            "answer": 0,
            "why": "Windows ARM64 arg1 is x0. rcx is the x64 Windows register, and x8 is the Linux syscall-number register."
          },
          {
            "q": "Which branch enters WriteFile?",
            "choices": [
              "bl WriteFile",
              "svc #0",
              "syscall",
              "int 21h"
            ],
            "answer": 0,
            "why": "bl calls the imported function. svc #0 would be a Linux-style supervisor call."
          },
          {
            "q": "Why is Linux syscall 64 the wrong thing to load for Windows write?",
            "choices": [
              "That number is the Linux generic write, not a Windows API",
              "ARM64 has no x0",
              "WriteFile takes no arguments",
              "Windows uses int 0x80"
            ],
            "answer": 0,
            "why": "64 is Linux write on the generic table. Windows applications call WriteFile."
          }
        ]
      },
      {
        "id": "a64w-2",
        "title": "Errors and ExitProcess",
        "teach": "WriteFile returns a BOOL in x0. Zero means failure, and GetLastError returns the reason. ExitProcess does not return. The stack must stay 16-byte aligned at the bl, just as on other 64-bit Windows ABIs. Assembly that calls these functions is ordinary AAPCS-like code with the Windows-specific register roles, not a syscall table.",
        "code": "bl WriteFile\ncbz x0, failed\nmov w0, #0\nbl ExitProcess",
        "questions": [
          {
            "q": "WriteFile returns 0 in x0. What happened?",
            "choices": [
              "The call failed; GetLastError has the code",
              "Zero bytes is a successful empty write with no error",
              "The process exited",
              "errno is 0, so the call worked"
            ],
            "answer": 0,
            "why": "A FALSE BOOL is failure. Success is nonzero. Empty successful writes still return TRUE."
          },
          {
            "q": "Which call ends the process?",
            "choices": [
              "bl ExitProcess",
              "svc #0 with x8=93",
              "syscall with rax=60",
              "ret"
            ],
            "answer": 0,
            "why": "ExitProcess is the Win32 exit. 93 and 60 are Linux exit numbers."
          },
          {
            "q": "What alignment does bl expect of SP?",
            "choices": [
              "16 bytes",
              "1 byte",
              "3 bytes",
              "32 bytes and nothing else"
            ],
            "answer": 0,
            "why": "The 64-bit Windows ABI requires 16-byte stack alignment at the call."
          }
        ]
      }
    ]
  },
  {
    "id": "riscv-linux",
    "title": "RISC-V",
    "blurb": "The instruction set, then Linux ecall. Windows has no RISC-V userspace.",
    "lessons": [
      {
        "id": "rva-1",
        "title": "Registers",
        "teach": "RISC-V has 32 integer registers, x0 through x31. x0 is hard-wired zero. x1 is ra, the return address. x2 is sp. x10 through x17 are a0 through a7, the argument and return registers. x8 through x9 and x18 through x27 are saved registers a function must preserve if it uses them. Linux and a future calling convention can assign roles, but the integer file itself is the same.",
        "code": "li a0, 1\n; a0 is x10, and x0 stays 0",
        "questions": [
          {
            "q": "Which register is always zero?",
            "choices": [
              "x0",
              "ra",
              "sp",
              "a0"
            ],
            "answer": 0,
            "why": "x0 ignores writes and reads as zero. ra is x1."
          },
          {
            "q": "Which ABI name is the stack pointer?",
            "choices": [
              "sp, which is x2",
              "a0",
              "x0",
              "ra"
            ],
            "answer": 0,
            "why": "The standard ABI uses x2 as sp and x1 as ra."
          },
          {
            "q": "Where does a function return an integer?",
            "choices": [
              "a0",
              "x0",
              "sp",
              "ra"
            ],
            "answer": 0,
            "why": "a0 is the first argument and the integer return register."
          }
        ]
      },
      {
        "id": "rva-2",
        "title": "Moving data and immediates",
        "teach": "There is no mov that takes an arbitrary immediate. addi rd, rs, imm adds a 12-bit immediate. addi rd, x0, 5 loads a small constant. mv rd, rs is addi rd, rs, 0. lui plants a 20-bit immediate into the top of a register. auipc adds that immediate to the current pc, which is how a position-independent address is built. A memory load is a separate instruction.",
        "code": "addi a0, x0, 5\nmv a1, a0\nlui a2, 0x12345",
        "questions": [
          {
            "q": "What is mv a1, a0?",
            "choices": [
              "addi a1, a0, 0",
              "A load from a0",
              "A syscall",
              "A store"
            ],
            "answer": 0,
            "why": "mv is a pseudo-instruction. It adds zero to copy the register."
          },
          {
            "q": "How do you put the small constant 5 in a0?",
            "choices": [
              "addi a0, x0, 5",
              "add a0, a0, a0",
              "ecall",
              "sd a0, 0(sp)"
            ],
            "answer": 0,
            "why": "Adding 5 to the zero register yields 5."
          },
          {
            "q": "What does lui write?",
            "choices": [
              "A 20-bit immediate into the upper bits",
              "The stack pointer",
              "Memory at pc",
              "a7"
            ],
            "answer": 0,
            "why": "lui is load-upper-immediate. The low 12 bits become zero."
          }
        ]
      },
      {
        "id": "rva-3",
        "title": "Arithmetic",
        "teach": "add rd, rs1, rs2 writes rs1+rs2 to rd. sub subtracts. addi is the immediate form and is also how you increment: addi a0, a0, 1. mul is part of the M extension, which general-purpose Linux machines provide. There are no condition flags. Nothing in add secretly prepares a later branch; the branch itself compares registers.",
        "code": "addi a0, x0, 40\naddi a0, a0, 2\naddi a0, a0, -1",
        "questions": [
          {
            "q": "After those three addi instructions, what is a0?",
            "choices": [
              "41",
              "40",
              "42",
              "2"
            ],
            "answer": 0,
            "why": "40+2-1 is 41. Each addi writes a0."
          },
          {
            "q": "Which instruction adds 1 to a0?",
            "choices": [
              "addi a0, a0, 1",
              "add a0, x0, x0",
              "lui a0, 1",
              "ecall"
            ],
            "answer": 0,
            "why": "addi with immediate 1 is the increment. There is no separate inc."
          },
          {
            "q": "Why does add not prepare a branch by itself?",
            "choices": [
              "RISC-V branches compare registers; there is no flags register",
              "add is illegal",
              "Branches read a7",
              "add writes memory"
            ],
            "answer": 0,
            "why": "beq and its relatives take two registers. They do not read leftover flags."
          }
        ]
      },
      {
        "id": "rva-4",
        "title": "Branches",
        "teach": "beq, bne, blt, and bge compare two registers and branch. bltu and bgeu are the unsigned forms. There is no cmp. The branch encodes the offset itself. jal writes the return address and jumps, including the short jal x0, label that discards the address and is an unconditional jump. A compare-and-branch does not need a flag-setting instruction in front of it.",
        "code": "blt a0, a1, less\nbeq a0, a1, same\njal x0, greater",
        "questions": [
          {
            "q": "Which branch is signed less-than?",
            "choices": [
              "blt",
              "bltu",
              "beq",
              "bgeu"
            ],
            "answer": 0,
            "why": "blt is signed. bltu is unsigned."
          },
          {
            "q": "How do you write an unconditional jump that does not save a return address?",
            "choices": [
              "jal x0, label",
              "beq x0, x0, label only",
              "ecall",
              "addi x0, x0, 1"
            ],
            "answer": 0,
            "why": "Writing the link into x0 discards it. jal x0 is the unconditional jump."
          },
          {
            "q": "What does beq compare?",
            "choices": [
              "Two registers",
              "A register and the flags",
              "a7 and a syscall number only",
              "Memory"
            ],
            "answer": 0,
            "why": "Both operands of beq are registers. There is no flags operand."
          }
        ]
      },
      {
        "id": "rva-5",
        "title": "Loops",
        "teach": "A counted loop subtracts or adds to the counter and branches while the comparison still holds. addi a1, a1, -1 followed by bne a1, x0, top runs until a1 is zero. Because the branch compares a1 with x0, you do not need a flags update. A test before the body, beq a1, x0, skip, is the zero-trip form. Do not use a1 for something else in the body if a1 is the counter.",
        "code": "addi a1, x0, 3\ntop:\nadd a0, a0, a2\naddi a1, a1, -1\nbne a1, x0, top",
        "questions": [
          {
            "q": "bne a1, x0, top keeps going while a1 is what?",
            "choices": [
              "Not zero",
              "Zero",
              "Equal to a0",
              "Negative only"
            ],
            "answer": 0,
            "why": "The branch is taken when a1 and x0 differ, so a zero counter falls through."
          },
          {
            "q": "Which register makes a convenient zero operand?",
            "choices": [
              "x0",
              "ra",
              "sp",
              "a7"
            ],
            "answer": 0,
            "why": "x0 is always zero, so comparing with x0 tests for zero."
          },
          {
            "q": "Where is the test in a loop that must not run when the count starts at zero?",
            "choices": [
              "Before the body",
              "After the first add",
              "In the loader",
              "In a7"
            ],
            "answer": 0,
            "why": "beq to the exit before the body skips every trip, including the first."
          }
        ]
      },
      {
        "id": "rva-6",
        "title": "Memory",
        "teach": "ld loads eight bytes and sd stores eight. lw and sw are 32-bit, and lw sign-extends into the destination. The address mode is a 12-bit displacement plus a register: ld a0, 8(a1) reads the address a1+8. There is no scaled-index operand. To index a qword array you shift the index left by 3, add the base, then ld from 0(that). The shift is a real instruction, slli, not a hidden part of ld.",
        "code": "slli t0, a2, 3\nadd t0, a1, t0\nld a0, 0(t0)",
        "questions": [
          {
            "q": "What does ld a0, 8(a1) load?",
            "choices": [
              "Eight bytes from a1+8",
              "The address a1+8",
              "Four bytes",
              "a1 into a0"
            ],
            "answer": 0,
            "why": "ld is a 64-bit load. The 8 is a byte displacement."
          },
          {
            "q": "Why is slli t0, a2, 3 used before indexing qwords?",
            "choices": [
              "A shift of 3 multiplies the index by 8",
              "It is the syscall number",
              "It clears a0",
              "ld requires a7"
            ],
            "answer": 0,
            "why": "The base ISA has no scale factor on the memory operand, so the multiply by element size is explicit."
          },
          {
            "q": "What does lw do with bits 32 through 63 of the destination?",
            "choices": [
              "Sign-extends the loaded word into them",
              "Leaves them unchanged",
              "Zeros them always",
              "Writes them to memory"
            ],
            "answer": 0,
            "why": "lw sign-extends. lw with a high bit set fills the top with ones."
          }
        ]
      },
      {
        "id": "rva-7",
        "title": "Calls and the stack",
        "teach": "jal ra, label writes the return address to ra and jumps. jalr ra, 0(a0) returns through a register, which is how ret is defined: jalr x0, 0(ra) discards a link and jumps to ra. The stack grows down. A function that calls another function saves ra in a stack slot, because the inner jal overwrites ra. Slots are addressed as offset(sp). sp must stay 16-byte aligned at a call on the standard ABI.",
        "code": "addi sp, sp, -16\nsd ra, 8(sp)\njal ra, work\nld ra, 8(sp)\naddi sp, sp, 16\njalr x0, 0(ra)",
        "questions": [
          {
            "q": "What does jal ra, work store in ra?",
            "choices": [
              "The address of the next instruction",
              "sp",
              "x0",
              "The syscall number"
            ],
            "answer": 0,
            "why": "jal links. The matching return jumps to that address."
          },
          {
            "q": "Why save ra before jal to another function?",
            "choices": [
              "The inner jal overwrites ra",
              "ra is hard-wired zero",
              "jal does not jump",
              "The stack grows up"
            ],
            "answer": 0,
            "why": "There is one return-address register. The outer address has to be in memory during the inner call."
          },
          {
            "q": "Which instruction is the usual ret?",
            "choices": [
              "jalr x0, 0(ra)",
              "jal ra, ra",
              "ecall",
              "beq ra, x0, ra"
            ],
            "answer": 0,
            "why": "jalr with x0 as the link register jumps to ra and does not write a new return address."
          }
        ]
      },
      {
        "id": "rva-8",
        "title": "Logic and shifts",
        "teach": "and, or, and xor are bitwise, with immediate forms andi, ori, and xori. slli, srli, and srai are left, logical right, and arithmetic right shifts. A left shift of one multiplies by two until the bit falls off. xor a0, a0, a0 clears a0. There is still no flags register: if you need to branch on a bit, andi a temporary with 1 and then beq that temporary with x0.",
        "code": "xor a0, a0, a0\nslli a1, a1, 1\nandi t0, a2, 1\nbeq t0, x0, even",
        "questions": [
          {
            "q": "How do you clear a0?",
            "choices": [
              "xor a0, a0, a0",
              "or a0, a0, a0",
              "slli a0, a0, 0",
              "sd a0, 0(sp)"
            ],
            "answer": 0,
            "why": "Xor of a register with itself is zero. or with itself keeps the value."
          },
          {
            "q": "Which shift preserves the sign bit?",
            "choices": [
              "srai",
              "srli",
              "slli",
              "xor"
            ],
            "answer": 0,
            "why": "srai is arithmetic. srli inserts zeros."
          },
          {
            "q": "How do you branch on the low bit being clear?",
            "choices": [
              "andi a temporary with 1, then beq it with x0",
              "Read a flags register",
              "ecall",
              "srai by 64"
            ],
            "answer": 0,
            "why": "The base ISA has no flags, so the test result has to land in a register the branch can compare."
          }
        ]
      },
      {
        "id": "rvl-1",
        "title": "ecall and a7",
        "teach": "RISC-V Linux enters the kernel with ecall. There is no immediate operand for the syscall number. The number is in a7. Arguments go in a0, a1, a2, a3, a4, and a5. The result comes back in a0, and a negative value in the -4095 to -1 range is -errno. a7 is the RISC-V counterpart of ARM64 x8, not of a0.",
        "code": "li a7, 64\nli a0, 1\nmv a1, s0\nmv a2, s1\necall",
        "questions": [
          {
            "q": "Which instruction enters the kernel on RISC-V Linux?",
            "choices": [
              "ecall",
              "svc #0",
              "syscall",
              "int 21h"
            ],
            "answer": 0,
            "why": "ecall is the RISC-V environment call."
          },
          {
            "q": "Which register holds the syscall number?",
            "choices": [
              "a7",
              "a0",
              "x8",
              "ra"
            ],
            "answer": 0,
            "why": "a0 is arg1 and the return value. a7 is the number. ra is the return address."
          },
          {
            "q": "The first three arguments of a syscall use which registers?",
            "choices": [
              "a0, a1, a2",
              "a7, a6, a5",
              "x0, x1, x2",
              "rdi, rsi, rdx"
            ],
            "answer": 0,
            "why": "Arguments start at a0. a7 is reserved for the number."
          }
        ]
      },
      {
        "id": "rvl-2",
        "title": "write and exit",
        "teach": "RISC-V Linux uses the generic syscall table, the same numbers as ARM64. write is 64, read is 63, exit is 93, and exit_group is 94. They are not the x86-64 numbers. For write, a0 is the descriptor, a1 is the buffer, and a2 is the count. A program that copies an x86-64 snippet and only swaps in ecall will call the wrong service.",
        "code": "li a7, 64\nli a0, 1\nmv a1, s0\nmv a2, s1\necall\nli a7, 93\nli a0, 0\necall",
        "questions": [
          {
            "q": "What is the RISC-V Linux number for write?",
            "choices": [
              "64",
              "1",
              "4",
              "93"
            ],
            "answer": 0,
            "why": "Generic write is 64, shared with ARM64 and different from both x86 ABIs."
          },
          {
            "q": "Which instruction and register exit with status 0?",
            "choices": [
              "ecall with a7 = 93 and a0 = 0",
              "ecall with a7 = 60 and a0 = 0",
              "svc #93",
              "syscall with rax = 93"
            ],
            "answer": 0,
            "why": "exit is 93 in a7. The instruction is ecall. 60 is x86-64's exit number."
          },
          {
            "q": "read's buffer pointer goes in which register?",
            "choices": [
              "a1",
              "a7",
              "a0",
              "x8"
            ],
            "answer": 0,
            "why": "a0 is the descriptor, a1 is the buffer, a2 is the count. a7 remains 63 for read."
          }
        ]
      },
      {
        "id": "rvl-3",
        "title": "The C library again",
        "teach": "The RISC-V C ABI already uses a0 through a7 for function arguments, with a0 and a1 for the return value. A call to write therefore looks like any other call: arguments in a0, a1, a2, then jal ra, write. The libc function sets a7 and executes ecall. Assembly that wants to skip libc sets a7 itself. Either way the kernel contract is the same; the choice is whether your program or the library fills in the number.",
        "code": "li a0, 1\nmv a1, s0\nmv a2, s1\njal ra, write",
        "questions": [
          {
            "q": "What does jal ra, write do?",
            "choices": [
              "It calls libc write, saving the return address in ra",
              "It performs ecall immediately",
              "It loads a7 with 1",
              "It is a DOS interrupt"
            ],
            "answer": 0,
            "why": "jal is a function call. The libc wrapper is what executes ecall."
          },
          {
            "q": "If you skip libc, which extra register must you set before ecall?",
            "choices": [
              "a7, to the syscall number",
              "ra, to the byte count",
              "sp, to the descriptor",
              "x8, to 64"
            ],
            "answer": 0,
            "why": "Without the wrapper, your code supplies the number in a7."
          },
          {
            "q": "Which statement is true of ARM64 and RISC-V Linux numbers?",
            "choices": [
              "They share the generic table, so write is 64 on both",
              "They share the x86-64 table, so write is 1 on both",
              "RISC-V uses DOS numbers",
              "The numbers are chosen by the C compiler at random"
            ],
            "answer": 0,
            "why": "Both ports use asm-generic: read 63, write 64, exit 93."
          }
        ]
      },
      {
        "id": "rvw-1",
        "title": "No Windows RISC-V userspace",
        "teach": "Microsoft Windows does not provide a RISC-V application platform comparable to Windows on x86 or ARM64. There is no kernel32 for RISC-V Windows to call, and there is no supported syscall number list for that combination. RISC-V programs that talk to an operating system today are Linux (and other Unix) programs using ecall. If a vendor later shipped Windows on RISC-V, the durable interface would still be a documented DLL and a calling convention, not a tutorial full of kernel build numbers.",
        "code": "; RISC-V Linux, not Windows\nli a7, 64\necall",
        "questions": [
          {
            "q": "Which operating system is the real RISC-V syscall target in this course?",
            "choices": [
              "Linux, via ecall",
              "Windows 95, via int 21h",
              "Windows 11, via kernel32 on RISC-V",
              "MS-DOS"
            ],
            "answer": 0,
            "why": "RISC-V system calls here are Linux ecall. Windows does not offer that userspace."
          },
          {
            "q": "Why does this course not list RISC-V Windows syscall numbers?",
            "choices": [
              "There is no supported Windows RISC-V application ABI to memorize",
              "ecall is illegal on RISC-V",
              "Windows uses the Linux generic numbers unchanged",
              "a7 cannot hold a number"
            ],
            "answer": 0,
            "why": "Inventing a Windows RISC-V syscall table would be fiction. Linux is the real interface."
          },
          {
            "q": "What would still be the right application interface if Windows gained RISC-V?",
            "choices": [
              "A documented library and calling convention",
              "Whatever NT number one build used",
              "int 0x80",
              "AH=09h"
            ],
            "answer": 0,
            "why": "Applications bind to a stable library. Raw kernel numbers are an internal detail and move."
          }
        ]
      }
    ]
  },
  {
    "id": "dos-win95",
    "title": "MS-DOS and Windows 95",
    "blurb": "INT 21h in real mode, and Win32 stdcall once Windows 95 is in protected mode.",
    "lessons": [
      {
        "id": "dos-1",
        "title": "Real mode and INT 21h",
        "teach": "MS-DOS programs run in real mode. Segment registers DS, ES, SS, and CS pick 64KB regions, and offsets such as DX point inside the segment. DOS services are interrupt 21h. AH selects the function. A .COM program is loaded at offset 100h in its segment, which is why DOS assembly uses ORG 100h. This is not a Linux syscall and it is not a Win32 call.",
        "code": "org 100h\nmov ah, 4Ch\nmov al, 0\nint 21h",
        "questions": [
          {
            "q": "Which interrupt reaches DOS?",
            "choices": [
              "int 21h",
              "syscall",
              "svc #0",
              "ecall"
            ],
            "answer": 0,
            "why": "DOS services are INT 21h. The other three are Linux entries on other architectures."
          },
          {
            "q": "Which register selects the DOS function?",
            "choices": [
              "AH",
              "RAX",
              "x8",
              "a7"
            ],
            "answer": 0,
            "why": "AH is the function number. AL often holds a subfunction or a result."
          },
          {
            "q": "Why do .COM programs start at ORG 100h?",
            "choices": [
              "DOS builds a 256-byte PSP and loads the image after it",
              "The CPU cannot execute at offset 0",
              "Windows 95 requires PE sections at 100h",
              "INT 21h only works at that address"
            ],
            "answer": 0,
            "why": "The Program Segment Prefix occupies 00h through FFh. The COM image begins at 100h."
          }
        ]
      },
      {
        "id": "dos-7",
        "title": "Loops with CX",
        "teach": "DOS-era x86 keeps a trip count in CX. The LOOP instruction decrements CX and jumps while CX is not zero. dec cx followed by jnz does the same and makes the flag test obvious. The body must not overwrite CX if CX is the counter. A compare of CX against zero before the body skips the loop when there is nothing to do. This is the same counted-loop shape as rcx on x86-64, in 16-bit registers.",
        "code": "mov cx, 3\nagain:\nadd ax, bx\nloop again",
        "questions": [
          {
            "q": "What does LOOP do with CX?",
            "choices": [
              "Decrements it and jumps while it is not zero",
              "Increments it",
              "Stores it to disk",
              "Loads AH"
            ],
            "answer": 0,
            "why": "LOOP is decrement-and-branch on CX."
          },
          {
            "q": "Which jump matches dec cx when you want to repeat until CX is zero?",
            "choices": [
              "jnz",
              "jz on the first test only",
              "int 21h",
              "ret"
            ],
            "answer": 0,
            "why": "dec sets ZF at zero. jnz repeats while the result is not zero."
          },
          {
            "q": "Why avoid using CX for something else inside a LOOP body?",
            "choices": [
              "LOOP is using CX as the counter",
              "CX cannot be read",
              "AH depends on CX",
              "DOS forbids CX"
            ],
            "answer": 0,
            "why": "If the body changes CX, the trip count is no longer the one LOOP expects."
          }
        ]
      },
      {
        "id": "dos-8",
        "title": "Addresses in a segment",
        "teach": "In real mode a pointer is a segment and an offset. DS:BX means the address (DS times 16) plus BX. mov ax, [bx] loads the word at DS:BX. mov [bx], ax stores it. You cannot name a 64-bit register; AX is 16 bits here. A byte load is mov al, [bx]. The segment is not optional just because the offset fits in BX. A buffer you passed to AH=40h is the same idea: DS:DX selects the bytes.",
        "code": "mov ax, [bx]\nmov [bx+2], ax",
        "questions": [
          {
            "q": "What does mov ax, [bx] load?",
            "choices": [
              "The word at DS:BX",
              "The segment DS into AX",
              "A qword",
              "AH only"
            ],
            "answer": 0,
            "why": "BX is the offset. DS supplies the segment. AX is 16 bits."
          },
          {
            "q": "How is a real-mode linear address formed?",
            "choices": [
              "Segment times 16, plus the offset",
              "The offset alone",
              "rsp plus the offset",
              "A page table walk only"
            ],
            "answer": 0,
            "why": "Real mode shifts the segment left by 4 bits and adds the offset."
          },
          {
            "q": "AH=40h reads the buffer from which pointer?",
            "choices": [
              "DS:DX",
              "CS:IP only",
              "x1",
              "a1"
            ],
            "answer": 0,
            "why": "DX is the offset and DS is the segment. CX is the length, BX the handle."
          }
        ]
      },
      {
        "id": "dos-2",
        "title": "Print a character and a string",
        "teach": "AH=02h writes the character in DL to standard output. AH=09h writes the dollar-terminated string at DS:DX. The dollar sign is the terminator, so it does not appear, and it cannot be part of the text. A string that should end on screen with a new line includes 0Dh and 0Ah before the dollar sign. AH=09h does not take a length; if you need a length, use AH=40h instead.",
        "code": "mov ah, 09h\nmov dx, msg\nint 21h\nmsg db 'Hi', 0Dh, 0Ah, '$'",
        "questions": [
          {
            "q": "AH=09h stops at which byte?",
            "choices": [
              "24h, the dollar character",
              "00h",
              "0Ah only",
              "The value in CX"
            ],
            "answer": 0,
            "why": "Function 09h is the dollar-string print. It does not use an explicit length."
          },
          {
            "q": "AH=02h sends the character in which register?",
            "choices": [
              "DL",
              "DH",
              "CX",
              "AL"
            ],
            "answer": 0,
            "why": "DL holds the character. AH is already 02h."
          },
          {
            "q": "Which bytes make a DOS new line before the terminator?",
            "choices": [
              "0Dh, 0Ah",
              "0Ah only, as on Unix",
              "svc #0",
              "A zero word"
            ],
            "answer": 0,
            "why": "DOS new lines are CR LF, then $ ends an AH=09h string."
          }
        ]
      },
      {
        "id": "dos-3",
        "title": "Write with a length",
        "teach": "AH=40h writes CX bytes from DS:DX to the handle in BX. Handle 1 is standard output. AX returns the number of bytes written. The carry flag is set on error. Unlike AH=09h, the buffer may contain dollar signs and explicit lengths, which is the right call for binary data. Handle 0 is standard input and handle 2 is standard error.",
        "code": "mov ah, 40h\nmov bx, 1\nmov cx, len\nmov dx, msg\nint 21h",
        "questions": [
          {
            "q": "AH=40h takes the handle in which register?",
            "choices": [
              "BX",
              "AX",
              "DS",
              "AH"
            ],
            "answer": 0,
            "why": "BX is the handle. CX is the count and DS:DX is the buffer."
          },
          {
            "q": "Which handle is standard output?",
            "choices": [
              "1",
              "0",
              "5",
              "21h"
            ],
            "answer": 0,
            "why": "0 is stdin, 1 is stdout, 2 is stderr."
          },
          {
            "q": "After a successful AH=40h, where is the byte count?",
            "choices": [
              "AX",
              "A negative errno in RAX",
              "DL",
              "x0"
            ],
            "answer": 0,
            "why": "DOS returns the count in AX and uses the carry flag for errors."
          }
        ]
      },
      {
        "id": "dos-4",
        "title": "Exit the program",
        "teach": "AH=4Ch ends the program. AL is the exit code that ERRORLEVEL sees in a batch file. INT 20h also returns to DOS from a COM whose CS is still the PSP segment, and a plain RET can do the same because offset 0 in the PSP holds an INT 20h. AH=4Ch is the one to teach, because it does not depend on CS and it passes a status. It is the DOS equivalent of Linux exit, not of Win32 ExitProcess.",
        "code": "mov ah, 4Ch\nmov al, 0\nint 21h",
        "questions": [
          {
            "q": "Which function exits with a status code?",
            "choices": [
              "AH=4Ch",
              "AH=09h",
              "AH=40h",
              "syscall 60"
            ],
            "answer": 0,
            "why": "4Ch is DOS exit. AL is the code. syscall 60 is x86-64 Linux."
          },
          {
            "q": "Where does the exit code go?",
            "choices": [
              "AL",
              "CX",
              "x8",
              "rdi"
            ],
            "answer": 0,
            "why": "AL is the ERRORLEVEL. AH selects function 4Ch."
          },
          {
            "q": "Why is RET able to leave a .COM program?",
            "choices": [
              "Offset 0 of the PSP contains an INT 20h, and the stack points there",
              "RET executes syscall",
              "RET is a Win32 call",
              "The CPU resets"
            ],
            "answer": 0,
            "why": "DOS places INT 20h at the start of the PSP and a zero word on the stack."
          }
        ]
      },
      {
        "id": "dos-5",
        "title": "COM versus EXE",
        "teach": "A .COM file is a raw memory image, no header, at most one segment of code and data together. An MZ .EXE has a header, can have a separate stack, and can be larger than 64KB. Windows 95 still runs both inside a DOS virtual machine. A Win32 program is neither of those: it is a Portable Executable, loaded by the Windows loader in protected mode. Use COM or MZ when you are writing DOS. Use PE when you are writing Win32.",
        "code": "; COM: org 100h, no header\n; EXE: MZ header, SS:SP from the header\n; Win32: PE, WinMain",
        "questions": [
          {
            "q": "Which file is a raw image with ORG 100h and no header?",
            "choices": [
              ".COM",
              "PE",
              "ELF",
              "MZ with a relocation table"
            ],
            "answer": 0,
            "why": "COM files have no header. MZ and PE both do."
          },
          {
            "q": "What does Windows 95 use for a 32-bit GUI program?",
            "choices": [
              "A PE",
              "Only a .COM",
              "An ELF",
              "A Linux syscall table"
            ],
            "answer": 0,
            "why": "Win32 binaries are Portable Executables, even on Windows 95."
          },
          {
            "q": "Where does Windows 95 still run an INT 21h program?",
            "choices": [
              "In a DOS virtual machine",
              "Inside kernel32 as a normal Win32 thread with no VM",
              "By converting it to svc #0",
              "It cannot run DOS programs at all"
            ],
            "answer": 0,
            "why": "DOS programs keep the INT 21h interface inside a virtual 8086 session. Win32 programs do not."
          }
        ]
      },
      {
        "id": "dos-6",
        "title": "Windows 95 Win32",
        "teach": "A Windows 95 GUI or console Win32 program starts at WinMain, not at ORG 100h. User32 and kernel32 are DLL imports. MessageBox and ExitProcess use stdcall: push arguments right to left, and the callee cleans the stack. MessageBox(NULL, text, caption, MB_OK) pushes MB_OK first and the HWND last. ExitProcess does not return. GetLastError, not the carry flag, reports Win32 failures. The DOS AH=4Ch exit is for DOS programs only.",
        "code": "push MB_OK\npush offset caption\npush offset text\npush 0\ncall MessageBoxA\npush 0\ncall ExitProcess",
        "questions": [
          {
            "q": "Which convention does 32-bit MessageBox use?",
            "choices": [
              "stdcall",
              "Linux syscall with rax",
              "ecall with a7",
              "AH=09h"
            ],
            "answer": 0,
            "why": "32-bit Win32 exports are stdcall. The callee removes the four dword arguments."
          },
          {
            "q": "In the snippet, what is pushed immediately before call MessageBoxA?",
            "choices": [
              "The HWND, which is 0",
              "MB_OK",
              "The DOS function number",
              "x8"
            ],
            "answer": 0,
            "why": "Right-to-left pushes leave the first argument, hWnd, next to the call."
          },
          {
            "q": "How does this Win32 program end?",
            "choices": [
              "call ExitProcess",
              "int 21h with AH=4Ch",
              "syscall",
              "RET to the PSP"
            ],
            "answer": 0,
            "why": "ExitProcess is the Win32 exit. AH=4Ch is the DOS exit used by COM programs."
          }
        ]
      }
    ]
  }
];
