(function () {
  const KEY = "systemsasmcomplete_progress_v1";
  const empty = () => ({ xp: 0, completed: {} });

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      const data = raw ? JSON.parse(raw) : null;
      if (!data || typeof data !== "object" || Array.isArray(data)) return empty();
      return {
        xp: Number(data.xp) || 0,
        completed: data.completed && typeof data.completed === "object" ? data.completed : {},
      };
    } catch (err) {
      return empty();
    }
  }

  function save(progress) {
    localStorage.setItem(KEY, JSON.stringify(progress));
  }

  const tracks = window.COURSE;
  const byTrack = Object.fromEntries(tracks.map((track) => [track.id, track]));
  let progress = load();
  let screen = { name: "home" };
  const picks = {};

  function lessonDone(id) {
    return !!progress.completed[id];
  }

  function unlocked(track, index) {
    if (index === 0) return true;
    return lessonDone(track.lessons[index - 1].id);
  }

  function resetProgress() {
    progress = empty();
    save(progress);
    screen = { name: "home" };
    try {
      location.reload();
    } catch (err) {
      render();
    }
  }

  function escape(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function home() {
    const cards = tracks.map((track) => {
      const done = track.lessons.filter((lesson) => lessonDone(lesson.id)).length;
      return `<button class="card${done === track.lessons.length ? " done" : ""}" data-act="track" data-id="${track.id}">
        <b>${escape(track.title)}</b>
        <span class="muted">${escape(track.blurb)}</span>
        <span class="muted">${done} / ${track.lessons.length} lessons</span>
      </button>`;
    }).join("");
    return `<p class="muted">Registers, arithmetic, branches, memory, and calls, then the system calls and calling conventions for Linux and Windows. MS-DOS and Windows 95 are the x86 track from that era. This app does not replace Bare Metal.</p>${cards}`;
  }

  function trackView(track) {
    const items = track.lessons.map((lesson, index) => {
      const open = unlocked(track, index);
      const done = lessonDone(lesson.id);
      return `<button class="card${done ? " done" : ""}" data-act="lesson" data-track="${track.id}" data-id="${lesson.id}" ${open ? "" : "disabled"}>
        <b>${index + 1}. ${escape(lesson.title)}</b>
        <span class="muted">${done ? "Passed" : open ? "Open" : "Locked"}</span>
      </button>`;
    }).join("");
    return `<button class="back" data-act="home">Back</button><h2>${escape(track.title)}</h2><p class="muted">${escape(track.blurb)}</p>${items}`;
  }

  function lessonView(track, lesson) {
    const questions = lesson.questions.map((question, qIndex) => {
      const choices = question.choices.map((choice, cIndex) => {
        const picked = picks[`${lesson.id}:${qIndex}`] === cIndex;
        return `<button class="choice${picked ? " picked" : ""}" data-act="pick" data-q="${qIndex}" data-c="${cIndex}">${escape(choice)}</button>`;
      }).join("");
      return `<div class="question"><p>${escape(question.q)}</p>${choices}<p class="why" data-why="${qIndex}" hidden></p></div>`;
    }).join("");
    const passed = lessonDone(lesson.id) ? `<p class="ok">Passed.</p>` : "";
    return `<button class="back" data-act="track" data-id="${track.id}">Back</button>
      <h2>${escape(lesson.title)}</h2>
      <p>${escape(lesson.teach)}</p>
      <pre>${escape(lesson.code)}</pre>
      ${questions}
      ${passed}
      <button class="primary" data-act="check" data-track="${track.id}" data-id="${lesson.id}">Check</button>`;
  }

  function shell(body) {
    return `<header>
      <div><h1>SystemsASMComplete</h1><div class="muted">Linux and Windows assembly</div></div>
      <div class="row"><span class="xp">${progress.xp} XP</span>
      <button class="ghost danger" data-act="reset">Reset progress</button></div>
    </header>${body}`;
  }

  function render() {
    let body = "";
    if (screen.name === "home") body = home();
    else if (screen.name === "track") body = trackView(byTrack[screen.id]);
    else if (screen.name === "lesson") {
      const track = byTrack[screen.track];
      const lesson = track.lessons.find((item) => item.id === screen.id);
      body = lessonView(track, lesson);
    }
    document.getElementById("app").innerHTML = shell(body);
  }

  document.body.addEventListener("click", (event) => {
    const el = event.target.closest("[data-act]");
    if (!el || el.disabled) return;
    const act = el.dataset.act;
    if (act === "home") {
      screen = { name: "home" };
      render();
    } else if (act === "track") {
      screen = { name: "track", id: el.dataset.id };
      render();
    } else if (act === "lesson") {
      screen = { name: "lesson", track: el.dataset.track, id: el.dataset.id };
      render();
    } else if (act === "pick") {
      picks[`${screen.id}:${el.dataset.q}`] = Number(el.dataset.c);
      render();
    } else if (act === "check") {
      const track = byTrack[el.dataset.track];
      const lesson = track.lessons.find((item) => item.id === el.dataset.id);
      let all = true;
      lesson.questions.forEach((question, qIndex) => {
        const chosen = picks[`${lesson.id}:${qIndex}`];
        const node = document.querySelector(`[data-q="${qIndex}"][data-c="${question.answer}"]`);
        const why = document.querySelector(`[data-why="${qIndex}"]`);
        if (node) node.classList.add("good");
        if (chosen !== question.answer) {
          all = false;
          const bad = document.querySelector(`[data-q="${qIndex}"][data-c="${chosen}"]`);
          if (bad) bad.classList.add("bad");
        }
        if (why) {
          why.hidden = false;
          why.textContent = question.why;
        }
      });
      if (all && !lessonDone(lesson.id)) {
        progress.completed[lesson.id] = true;
        progress.xp += 10;
        save(progress);
        const header = document.querySelector(".xp");
        if (header) header.textContent = `${progress.xp} XP`;
      }
      const note = document.createElement("p");
      note.className = all ? "ok" : "badtext";
      note.textContent = all ? "Passed. Progress is saved on this device." : "Not yet. The marked answers are the ones to study.";
      document.querySelector("[data-act=check]").before(note);
    } else if (act === "reset") {
      resetProgress();
    }
  });

  render();
})();
