window.COURSE = [
  {
    "id": "x86-linux",
    "title": "x86-64 Linux",
    "blurb": "The syscall instruction, the System V argument registers, and the x86-64 numbers.",
    "lessons": [
      {
        "id": "x86l-1",
        "title": "The syscall instruction",
        "teach": "On x86-64 Linux a user program enters the kernel with the syscall instruction, not with int 0x80. rax holds the syscall number. The arguments go in rdi, rsi, rdx, r10, r8, r9, in that order. rcx is not an argument: the processor uses rcx to save the return address, so the fourth argument is r10. The result comes back in rax. A value from -4095 to -1 is a negative errno.",
        "code": "mov rax, 1\nmov rdi, 1\nmov rsi, msg\nmov rdx, len\nsyscall",
        "questions": [
          {
            "q": "Which instruction do x86-64 Linux programs use to enter the kernel?",
            "choices": [
              "syscall",
              "svc #0",
              "ecall",
              "int 21h"
            ],
            "answer": 0,
            "why": "syscall is the x86-64 entry. svc is ARM64, ecall is RISC-V, and int 21h is DOS."
          },
          {
            "q": "Which register holds the syscall number?",
            "choices": [
              "rax",
              "rdi",
              "rcx",
              "r10"
            ],
            "answer": 0,
            "why": "rax is the number. rdi is the first argument."
          },
          {
            "q": "Why is the fourth argument in r10 rather than rcx?",
            "choices": [
              "syscall uses rcx internally, so the ABI moved that argument to r10",
              "rcx cannot hold a pointer",
              "Linux ignores the fourth argument",
              "r10 is the stack pointer"
            ],
            "answer": 0,
            "why": "The syscall instruction saves the return RIP in rcx. The Linux ABI therefore uses r10 for arg4."
          }
        ]
      },
      {
        "id": "x86l-2",
        "title": "write and exit",
        "teach": "write is syscall 1. rdi is the file descriptor, rsi is the buffer, and rdx is the byte count. File descriptor 1 is standard output. exit is syscall 60. rdi is the status code. exit does not return to the next instruction when it succeeds. A short program writes its message, then exits with status 0.",
        "code": "mov rax, 1\nmov rdi, 1\nmov rsi, msg\nmov rdx, msg_len\nsyscall\nmov rax, 60\nxor rdi, rdi\nsyscall",
        "questions": [
          {
            "q": "What is the x86-64 Linux number for write?",
            "choices": [
              "1",
              "4",
              "64",
              "60"
            ],
            "answer": 0,
            "why": "On x86-64, write is 1. The i386 int 0x80 number is 4, and the generic ARM64/RISC-V number is 64."
          },
          {
            "q": "A write to standard output puts which value in rdi?",
            "choices": [
              "1, the stdout descriptor",
              "0, the stdin descriptor",
              "60, the exit number",
              "The byte count"
            ],
            "answer": 0,
            "why": "rdi is arg1, the file descriptor. stdout is 1. The count belongs in rdx."
          },
          {
            "q": "Which pair exits with status 0?",
            "choices": [
              "rax = 60 and rdi = 0",
              "rax = 1 and rdi = 0",
              "rax = 60 and rsi = 0",
              "rax = 4 and rbx = 0"
            ],
            "answer": 0,
            "why": "60 is exit. rdi is the status. rsi is not an exit argument."
          }
        ]
      },
      {
        "id": "x86l-3",
        "title": "read, open, and errno",
        "teach": "read is syscall 0. open is syscall 2. For open, rdi is the path pointer, rsi is the flags, and rdx is the mode used when creating a file. O_RDONLY is 0. A non-negative rax is a file descriptor or a byte count. A rax in -1 through -4095 is -errno, so -2 means ENOENT. Programs that want a stable API usually call the libc wrappers read, write, and open, which turn that negative rax into -1 and set errno.",
        "code": "mov rax, 2\nmov rdi, path\nxor rsi, rsi\nsyscall\ncmp rax, 0\njl failed",
        "questions": [
          {
            "q": "open returns -2 in rax. What does that mean?",
            "choices": [
              "The call failed with errno 2 (ENOENT)",
              "The new descriptor is 2",
              "Two bytes were read",
              "The path was opened twice"
            ],
            "answer": 0,
            "why": "Negative returns from -1 to -4095 are -errno. -2 is ENOENT, not a descriptor."
          },
          {
            "q": "Which register holds the flags argument to open?",
            "choices": [
              "rsi",
              "rdi",
              "rax",
              "r10"
            ],
            "answer": 0,
            "why": "rdi is the path, rsi is the flags, rdx is the mode."
          },
          {
            "q": "Why do most programs call libc read instead of the syscall instruction?",
            "choices": [
              "libc turns a negative errno into the usual -1 return and an errno value",
              "The syscall instruction cannot read files",
              "libc uses a different kernel",
              "read has no syscall number"
            ],
            "answer": 0,
            "why": "The raw ABI returns -errno in rax. libc is the stable wrapper C programs are written against."
          }
        ]
      },
      {
        "id": "x86l-4",
        "title": "i386 int 0x80",
        "teach": "32-bit Linux uses int 0x80. eax is the number. Arguments go in ebx, ecx, edx, esi, edi, ebp. The numbers are not the x86-64 numbers: write is 4, read is 3, and exit is 1. A 64-bit kernel still accepts int 0x80 from a 32-bit process, but new 64-bit code should use syscall. Mixing the two numbering schemes is a common bug.",
        "code": "mov eax, 4\nmov ebx, 1\nmov ecx, msg\nmov edx, len\nint 0x80",
        "questions": [
          {
            "q": "Under int 0x80, which register holds the syscall number?",
            "choices": [
              "eax",
              "rax",
              "ebx",
              "x8"
            ],
            "answer": 0,
            "why": "The i386 ABI uses eax. rax is the 64-bit register name used with syscall."
          },
          {
            "q": "What is the i386 number for write?",
            "choices": [
              "4",
              "1",
              "64",
              "60"
            ],
            "answer": 0,
            "why": "i386 write is 4. x86-64 write is 1."
          },
          {
            "q": "A 32-bit program puts the buffer pointer for write in which register?",
            "choices": [
              "ecx",
              "ebx",
              "rsi",
              "rdx"
            ],
            "answer": 0,
            "why": "ebx is the descriptor, ecx is the buffer, edx is the length."
          }
        ]
      }
    ]
  },
  {
    "id": "x86-windows",
    "title": "x86 Windows",
    "blurb": "Call kernel32. Do not bake NT syscall numbers into an application.",
    "lessons": [
      {
        "id": "x86w-1",
        "title": "Call kernel32, not syscall",
        "teach": "A normal Windows program does not put a number in rax and execute syscall. It calls exported functions such as WriteFile and ExitProcess in kernel32.dll. Those functions live in ntdll's syscall stubs, and the numbers behind the stubs change between Windows builds. The stable contract is the documented Win32 function, its arguments, and GetLastError. Hard-coding an NT number ties the program to one kernel build.",
        "code": "extern ExitProcess\ncall ExitProcess",
        "questions": [
          {
            "q": "What should an ordinary Windows application call to exit?",
            "choices": [
              "ExitProcess in kernel32",
              "syscall number 60",
              "int 21h with AH=4Ch",
              "ecall with a7=93"
            ],
            "answer": 0,
            "why": "ExitProcess is the Win32 API. 60 and 93 are Linux numbers. int 21h is DOS."
          },
          {
            "q": "Why are raw NT syscall numbers a poor API for applications?",
            "choices": [
              "Microsoft changes them between builds; kernel32 is the stable surface",
              "Windows has no kernel",
              "kernel32 cannot return errors",
              "WriteFile is only a DOS interrupt"
            ],
            "answer": 0,
            "why": "The supported entry is the DLL export. The syscall stub underneath is an OS internal."
          },
          {
            "q": "After WriteFile returns FALSE, where does a Win32 program look for the reason?",
            "choices": [
              "GetLastError",
              "rax as -errno",
              "AH",
              "a7"
            ],
            "answer": 0,
            "why": "Win32 reports failure with a FALSE return and a separate last-error code."
          }
        ]
      },
      {
        "id": "x86w-2",
        "title": "The x64 calling convention",
        "teach": "64-bit Windows passes the first four integer arguments in rcx, rdx, r8, and r9. Further arguments go on the stack. The caller reserves 32 bytes of shadow space and keeps RSP 16-byte aligned at the call. The caller pops stack arguments. The return value is in rax. WriteFile's handle is therefore rcx, the buffer is rdx, the count is r8, and the pointer that receives the byte count is r9.",
        "code": "sub rsp, 40\nmov rcx, handle\nmov rdx, buffer\nmov r8d, count\nmov r9, bytes_written\nmov qword [rsp+32], 0\ncall WriteFile\nadd rsp, 40",
        "questions": [
          {
            "q": "WriteFile's HANDLE argument belongs in which register?",
            "choices": [
              "rcx",
              "rdi",
              "rax",
              "r10"
            ],
            "answer": 0,
            "why": "Windows x64 arg1 is rcx. rdi is the Linux syscall arg1."
          },
          {
            "q": "Who removes stack arguments after a Win64 call?",
            "choices": [
              "The caller",
              "The callee, as in stdcall",
              "The kernel",
              "Nobody"
            ],
            "answer": 0,
            "why": "The Microsoft x64 convention is caller-cleanup, unlike 32-bit stdcall."
          },
          {
            "q": "How much shadow space does the caller reserve?",
            "choices": [
              "32 bytes",
              "0 bytes",
              "8 bytes",
              "320 bytes"
            ],
            "answer": 0,
            "why": "Four argument slots, 8 bytes each, even when the arguments are already in registers."
          }
        ]
      },
      {
        "id": "x86w-3",
        "title": "32-bit stdcall",
        "teach": "32-bit Win32 uses stdcall. Arguments are pushed right to left, so the last argument is pushed first and the first argument is the last push before the call. The callee removes the arguments. EAX holds the return value. WriteFile has five 4-byte arguments, so it cleans 20 bytes off the stack. This is the convention Windows 95 Win32 programs used, and it is still the convention for 32-bit Windows binaries.",
        "code": "push 0\npush offset bytes_written\npush count\npush offset buffer\npush handle\ncall WriteFile",
        "questions": [
          {
            "q": "In the stdcall snippet, which value is pushed last, immediately before call WriteFile?",
            "choices": [
              "The HANDLE",
              "The overlapped pointer",
              "The byte count",
              "The return address"
            ],
            "answer": 0,
            "why": "Right-to-left order means the first parameter, the handle, is closest to the call."
          },
          {
            "q": "How many bytes does a 32-bit WriteFile remove from the stack?",
            "choices": [
              "20",
              "32",
              "4",
              "0"
            ],
            "answer": 0,
            "why": "Five dword parameters, and stdcall makes the callee clean them up."
          },
          {
            "q": "Where is the BOOL result?",
            "choices": [
              "EAX",
              "RAX as -errno",
              "AH",
              "ECX"
            ],
            "answer": 0,
            "why": "32-bit Win32 returns integer results in EAX."
          }
        ]
      }
    ]
  },
  {
    "id": "arm64-linux",
    "title": "ARM64 Linux",
    "blurb": "svc #0, the number in x8, and the generic Linux syscall table.",
    "lessons": [
      {
        "id": "a64l-1",
        "title": "svc and x8",
        "teach": "ARM64 Linux enters the kernel with svc #0. The immediate is zero; the syscall number is in x8, not in the immediate. Arguments go in x0, x1, x2, x3, x4, and x5. The result comes back in x0. As on other Linux ports, a value from -4095 to -1 is -errno. x30 is the link register and is not a syscall argument.",
        "code": "mov x8, #64\nmov x0, #1\nldr x1, =msg\nmov x2, #len\nsvc #0",
        "questions": [
          {
            "q": "Which instruction enters the kernel on ARM64 Linux?",
            "choices": [
              "svc #0",
              "syscall",
              "ecall",
              "int 0x80"
            ],
            "answer": 0,
            "why": "svc is the ARM supervisor call. The Linux number still lives in x8."
          },
          {
            "q": "Which register holds the syscall number?",
            "choices": [
              "x8",
              "x0",
              "x7",
              "rax"
            ],
            "answer": 0,
            "why": "x0 is the first argument and the return value. x8 is the number."
          },
          {
            "q": "What does an x0 result of -13 mean?",
            "choices": [
              "The call failed with errno 13",
              "Thirteen bytes were written",
              "The descriptor is 13",
              "svc was given an immediate of 13"
            ],
            "answer": 0,
            "why": "Linux returns -errno in the result register. -13 is EACCES."
          }
        ]
      },
      {
        "id": "a64l-2",
        "title": "write and exit",
        "teach": "ARM64 uses the generic syscall table, not the x86-64 numbers. write is 64. exit is 93, and exit_group is 94. For write, x0 is the file descriptor, x1 is the buffer, and x2 is the count. For exit, x0 is the status. Learning the x86-64 number 1 for write and then using it in x8 on ARM64 calls a different kernel service.",
        "code": "mov x8, #64\nmov x0, #1\nmov x1, x19\nmov x2, x20\nsvc #0\nmov x8, #93\nmov x0, #0\nsvc #0",
        "questions": [
          {
            "q": "What is the ARM64 Linux number for write?",
            "choices": [
              "64",
              "1",
              "4",
              "93"
            ],
            "answer": 0,
            "why": "The generic table uses 64 for write. x86-64 uses 1."
          },
          {
            "q": "Which registers does write use for descriptor, buffer, and count?",
            "choices": [
              "x0, x1, x2",
              "x8, x0, x1",
              "rdi, rsi, rdx",
              "a7, a0, a1"
            ],
            "answer": 0,
            "why": "x8 is only the number. The first three arguments are x0, x1, and x2."
          },
          {
            "q": "Which number exits the process?",
            "choices": [
              "93 in x8",
              "60 in x8",
              "1 in x0",
              "64 in x8"
            ],
            "answer": 0,
            "why": "exit is 93 on the generic table. 60 is the x86-64 exit number."
          }
        ]
      },
      {
        "id": "a64l-3",
        "title": "libc on ARM64",
        "teach": "The AAPCS64 calling convention used by C puts the first arguments in x0 through x7, and the return value in x0. That lines up with the syscall argument registers, but a C call to write still goes to libc, which moves the arguments into place and sets x8. A compiler calling write(1, buf, len) is not required to emit svc itself. The libc wrapper is the portable surface; the svc sequence is what you write in assembly when you are not linking that wrapper.",
        "code": "mov x0, #1\nmov x1, x19\nmov x2, x20\nbl write",
        "questions": [
          {
            "q": "A C call to write on ARM64 puts the file descriptor in which register?",
            "choices": [
              "x0",
              "x8",
              "x30",
              "sp"
            ],
            "answer": 0,
            "why": "AAPCS64 arg1 is x0. x8 becomes the syscall number only inside the libc stub or your own assembly."
          },
          {
            "q": "What does bl write do?",
            "choices": [
              "It calls the libc wrapper, which will issue svc",
              "It enters the kernel immediately",
              "It is the DOS print-string call",
              "It stores x8"
            ],
            "answer": 0,
            "why": "bl is a normal function call. The wrapper, not the call site, performs svc."
          },
          {
            "q": "Which register is the link register, not a syscall argument?",
            "choices": [
              "x30",
              "x0",
              "x1",
              "x8"
            ],
            "answer": 0,
            "why": "x30 holds the return address for bl and ret."
          }
        ]
      }
    ]
  },
  {
    "id": "arm64-windows",
    "title": "ARM64 Windows",
    "blurb": "The same Win32 functions, with the ARM64 argument registers.",
    "lessons": [
      {
        "id": "a64w-1",
        "title": "Win32 on ARM64",
        "teach": "Windows on ARM64 still wants applications to call kernel32 and the other documented DLLs. The processor is ARM64, so the calling convention is the Windows ARM64 convention: integer arguments in x0 through x7, return value in x0, and x8 available as indirect-result scratch rather than as a Linux syscall number. Do not put the Linux write number 64 in x8 and execute svc from an application. That is the Linux ABI, and the NT numbers behind ntdll are versioned internals.",
        "code": "mov x0, x19\nmov x1, x20\nmov w2, w21\nmov x3, x22\nbl WriteFile",
        "questions": [
          {
            "q": "Where does an ARM64 Windows call to WriteFile put the HANDLE?",
            "choices": [
              "x0",
              "x8",
              "rcx",
              "rax"
            ],
            "answer": 0,
            "why": "Windows ARM64 arg1 is x0. rcx is the x64 Windows register, and x8 is the Linux syscall-number register."
          },
          {
            "q": "Which branch enters WriteFile?",
            "choices": [
              "bl WriteFile",
              "svc #0",
              "syscall",
              "int 21h"
            ],
            "answer": 0,
            "why": "bl calls the imported function. svc #0 would be a Linux-style supervisor call."
          },
          {
            "q": "Why is Linux syscall 64 the wrong thing to load for Windows write?",
            "choices": [
              "That number is the Linux generic write, not a Windows API",
              "ARM64 has no x0",
              "WriteFile takes no arguments",
              "Windows uses int 0x80"
            ],
            "answer": 0,
            "why": "64 is Linux write on the generic table. Windows applications call WriteFile."
          }
        ]
      },
      {
        "id": "a64w-2",
        "title": "Errors and ExitProcess",
        "teach": "WriteFile returns a BOOL in x0. Zero means failure, and GetLastError returns the reason. ExitProcess does not return. The stack must stay 16-byte aligned at the bl, just as on other 64-bit Windows ABIs. Assembly that calls these functions is ordinary AAPCS-like code with the Windows-specific register roles, not a syscall table.",
        "code": "bl WriteFile\ncbz x0, failed\nmov w0, #0\nbl ExitProcess",
        "questions": [
          {
            "q": "WriteFile returns 0 in x0. What happened?",
            "choices": [
              "The call failed; GetLastError has the code",
              "Zero bytes is a successful empty write with no error",
              "The process exited",
              "errno is 0, so the call worked"
            ],
            "answer": 0,
            "why": "A FALSE BOOL is failure. Success is nonzero. Empty successful writes still return TRUE."
          },
          {
            "q": "Which call ends the process?",
            "choices": [
              "bl ExitProcess",
              "svc #0 with x8=93",
              "syscall with rax=60",
              "ret"
            ],
            "answer": 0,
            "why": "ExitProcess is the Win32 exit. 93 and 60 are Linux exit numbers."
          },
          {
            "q": "What alignment does bl expect of SP?",
            "choices": [
              "16 bytes",
              "1 byte",
              "3 bytes",
              "32 bytes and nothing else"
            ],
            "answer": 0,
            "why": "The 64-bit Windows ABI requires 16-byte stack alignment at the call."
          }
        ]
      }
    ]
  },
  {
    "id": "riscv-linux",
    "title": "RISC-V Linux",
    "blurb": "ecall, the number in a7, and the same generic numbers as ARM64.",
    "lessons": [
      {
        "id": "rvl-1",
        "title": "ecall and a7",
        "teach": "RISC-V Linux enters the kernel with ecall. There is no immediate operand for the syscall number. The number is in a7. Arguments go in a0, a1, a2, a3, a4, and a5. The result comes back in a0, and a negative value in the -4095 to -1 range is -errno. a7 is the RISC-V counterpart of ARM64 x8, not of a0.",
        "code": "li a7, 64\nli a0, 1\nmv a1, s0\nmv a2, s1\necall",
        "questions": [
          {
            "q": "Which instruction enters the kernel on RISC-V Linux?",
            "choices": [
              "ecall",
              "svc #0",
              "syscall",
              "int 21h"
            ],
            "answer": 0,
            "why": "ecall is the RISC-V environment call."
          },
          {
            "q": "Which register holds the syscall number?",
            "choices": [
              "a7",
              "a0",
              "x8",
              "ra"
            ],
            "answer": 0,
            "why": "a0 is arg1 and the return value. a7 is the number. ra is the return address."
          },
          {
            "q": "The first three arguments of a syscall use which registers?",
            "choices": [
              "a0, a1, a2",
              "a7, a6, a5",
              "x0, x1, x2",
              "rdi, rsi, rdx"
            ],
            "answer": 0,
            "why": "Arguments start at a0. a7 is reserved for the number."
          }
        ]
      },
      {
        "id": "rvl-2",
        "title": "write and exit",
        "teach": "RISC-V Linux uses the generic syscall table, the same numbers as ARM64. write is 64, read is 63, exit is 93, and exit_group is 94. They are not the x86-64 numbers. For write, a0 is the descriptor, a1 is the buffer, and a2 is the count. A program that copies an x86-64 snippet and only swaps in ecall will call the wrong service.",
        "code": "li a7, 64\nli a0, 1\nmv a1, s0\nmv a2, s1\necall\nli a7, 93\nli a0, 0\necall",
        "questions": [
          {
            "q": "What is the RISC-V Linux number for write?",
            "choices": [
              "64",
              "1",
              "4",
              "93"
            ],
            "answer": 0,
            "why": "Generic write is 64, shared with ARM64 and different from both x86 ABIs."
          },
          {
            "q": "Which instruction and register exit with status 0?",
            "choices": [
              "ecall with a7 = 93 and a0 = 0",
              "ecall with a7 = 60 and a0 = 0",
              "svc #93",
              "syscall with rax = 93"
            ],
            "answer": 0,
            "why": "exit is 93 in a7. The instruction is ecall. 60 is x86-64's exit number."
          },
          {
            "q": "read's buffer pointer goes in which register?",
            "choices": [
              "a1",
              "a7",
              "a0",
              "x8"
            ],
            "answer": 0,
            "why": "a0 is the descriptor, a1 is the buffer, a2 is the count. a7 remains 63 for read."
          }
        ]
      },
      {
        "id": "rvl-3",
        "title": "The C library again",
        "teach": "The RISC-V C ABI already uses a0 through a7 for function arguments, with a0 and a1 for the return value. A call to write therefore looks like any other call: arguments in a0, a1, a2, then jal ra, write. The libc function sets a7 and executes ecall. Assembly that wants to skip libc sets a7 itself. Either way the kernel contract is the same; the choice is whether your program or the library fills in the number.",
        "code": "li a0, 1\nmv a1, s0\nmv a2, s1\njal ra, write",
        "questions": [
          {
            "q": "What does jal ra, write do?",
            "choices": [
              "It calls libc write, saving the return address in ra",
              "It performs ecall immediately",
              "It loads a7 with 1",
              "It is a DOS interrupt"
            ],
            "answer": 0,
            "why": "jal is a function call. The libc wrapper is what executes ecall."
          },
          {
            "q": "If you skip libc, which extra register must you set before ecall?",
            "choices": [
              "a7, to the syscall number",
              "ra, to the byte count",
              "sp, to the descriptor",
              "x8, to 64"
            ],
            "answer": 0,
            "why": "Without the wrapper, your code supplies the number in a7."
          },
          {
            "q": "Which statement is true of ARM64 and RISC-V Linux numbers?",
            "choices": [
              "They share the generic table, so write is 64 on both",
              "They share the x86-64 table, so write is 1 on both",
              "RISC-V uses DOS numbers",
              "The numbers are chosen by the C compiler at random"
            ],
            "answer": 0,
            "why": "Both ports use asm-generic: read 63, write 64, exit 93."
          }
        ]
      }
    ]
  },
  {
    "id": "riscv-windows",
    "title": "RISC-V and Windows",
    "blurb": "Windows does not ship a RISC-V userspace. The lesson is the stable API.",
    "lessons": [
      {
        "id": "rvw-1",
        "title": "No Windows RISC-V userspace",
        "teach": "Microsoft Windows does not provide a RISC-V application platform comparable to Windows on x86 or ARM64. There is no kernel32 for RISC-V Windows to call, and there is no supported syscall number list for that combination. RISC-V programs that talk to an operating system today are Linux (and other Unix) programs using ecall. If a vendor later shipped Windows on RISC-V, the durable interface would still be a documented DLL and a calling convention, not a tutorial full of kernel build numbers.",
        "code": "; RISC-V Linux, not Windows\nli a7, 64\necall",
        "questions": [
          {
            "q": "Which operating system is the real RISC-V syscall target in this course?",
            "choices": [
              "Linux, via ecall",
              "Windows 95, via int 21h",
              "Windows 11, via kernel32 on RISC-V",
              "MS-DOS"
            ],
            "answer": 0,
            "why": "RISC-V system calls here are Linux ecall. Windows does not offer that userspace."
          },
          {
            "q": "Why does this course not list RISC-V Windows syscall numbers?",
            "choices": [
              "There is no supported Windows RISC-V application ABI to memorize",
              "ecall is illegal on RISC-V",
              "Windows uses the Linux generic numbers unchanged",
              "a7 cannot hold a number"
            ],
            "answer": 0,
            "why": "Inventing a Windows RISC-V syscall table would be fiction. Linux is the real interface."
          },
          {
            "q": "What would still be the right application interface if Windows gained RISC-V?",
            "choices": [
              "A documented library and calling convention",
              "Whatever NT number one build used",
              "int 0x80",
              "AH=09h"
            ],
            "answer": 0,
            "why": "Applications bind to a stable library. Raw kernel numbers are an internal detail and move."
          }
        ]
      }
    ]
  },
  {
    "id": "dos-win95",
    "title": "MS-DOS and Windows 95",
    "blurb": "INT 21h in real mode, and Win32 stdcall once Windows 95 is in protected mode.",
    "lessons": [
      {
        "id": "dos-1",
        "title": "Real mode and INT 21h",
        "teach": "MS-DOS programs run in real mode. Segment registers DS, ES, SS, and CS pick 64KB regions, and offsets such as DX point inside the segment. DOS services are interrupt 21h. AH selects the function. A .COM program is loaded at offset 100h in its segment, which is why DOS assembly uses ORG 100h. This is not a Linux syscall and it is not a Win32 call.",
        "code": "org 100h\nmov ah, 4Ch\nmov al, 0\nint 21h",
        "questions": [
          {
            "q": "Which interrupt reaches DOS?",
            "choices": [
              "int 21h",
              "syscall",
              "svc #0",
              "ecall"
            ],
            "answer": 0,
            "why": "DOS services are INT 21h. The other three are Linux entries on other architectures."
          },
          {
            "q": "Which register selects the DOS function?",
            "choices": [
              "AH",
              "RAX",
              "x8",
              "a7"
            ],
            "answer": 0,
            "why": "AH is the function number. AL often holds a subfunction or a result."
          },
          {
            "q": "Why do .COM programs start at ORG 100h?",
            "choices": [
              "DOS builds a 256-byte PSP and loads the image after it",
              "The CPU cannot execute at offset 0",
              "Windows 95 requires PE sections at 100h",
              "INT 21h only works at that address"
            ],
            "answer": 0,
            "why": "The Program Segment Prefix occupies 00h through FFh. The COM image begins at 100h."
          }
        ]
      },
      {
        "id": "dos-2",
        "title": "Print a character and a string",
        "teach": "AH=02h writes the character in DL to standard output. AH=09h writes the dollar-terminated string at DS:DX. The dollar sign is the terminator, so it does not appear, and it cannot be part of the text. A string that should end on screen with a new line includes 0Dh and 0Ah before the dollar sign. AH=09h does not take a length; if you need a length, use AH=40h instead.",
        "code": "mov ah, 09h\nmov dx, msg\nint 21h\nmsg db 'Hi', 0Dh, 0Ah, '$'",
        "questions": [
          {
            "q": "AH=09h stops at which byte?",
            "choices": [
              "24h, the dollar character",
              "00h",
              "0Ah only",
              "The value in CX"
            ],
            "answer": 0,
            "why": "Function 09h is the dollar-string print. It does not use an explicit length."
          },
          {
            "q": "AH=02h sends the character in which register?",
            "choices": [
              "DL",
              "DH",
              "CX",
              "AL"
            ],
            "answer": 0,
            "why": "DL holds the character. AH is already 02h."
          },
          {
            "q": "Which bytes make a DOS new line before the terminator?",
            "choices": [
              "0Dh, 0Ah",
              "0Ah only, as on Unix",
              "svc #0",
              "A zero word"
            ],
            "answer": 0,
            "why": "DOS new lines are CR LF, then $ ends an AH=09h string."
          }
        ]
      },
      {
        "id": "dos-3",
        "title": "Write with a length",
        "teach": "AH=40h writes CX bytes from DS:DX to the handle in BX. Handle 1 is standard output. AX returns the number of bytes written. The carry flag is set on error. Unlike AH=09h, the buffer may contain dollar signs and explicit lengths, which is the right call for binary data. Handle 0 is standard input and handle 2 is standard error.",
        "code": "mov ah, 40h\nmov bx, 1\nmov cx, len\nmov dx, msg\nint 21h",
        "questions": [
          {
            "q": "AH=40h takes the handle in which register?",
            "choices": [
              "BX",
              "AX",
              "DS",
              "AH"
            ],
            "answer": 0,
            "why": "BX is the handle. CX is the count and DS:DX is the buffer."
          },
          {
            "q": "Which handle is standard output?",
            "choices": [
              "1",
              "0",
              "5",
              "21h"
            ],
            "answer": 0,
            "why": "0 is stdin, 1 is stdout, 2 is stderr."
          },
          {
            "q": "After a successful AH=40h, where is the byte count?",
            "choices": [
              "AX",
              "A negative errno in RAX",
              "DL",
              "x0"
            ],
            "answer": 0,
            "why": "DOS returns the count in AX and uses the carry flag for errors."
          }
        ]
      },
      {
        "id": "dos-4",
        "title": "Exit the program",
        "teach": "AH=4Ch ends the program. AL is the exit code that ERRORLEVEL sees in a batch file. INT 20h also returns to DOS from a COM whose CS is still the PSP segment, and a plain RET can do the same because offset 0 in the PSP holds an INT 20h. AH=4Ch is the one to teach, because it does not depend on CS and it passes a status. It is the DOS equivalent of Linux exit, not of Win32 ExitProcess.",
        "code": "mov ah, 4Ch\nmov al, 0\nint 21h",
        "questions": [
          {
            "q": "Which function exits with a status code?",
            "choices": [
              "AH=4Ch",
              "AH=09h",
              "AH=40h",
              "syscall 60"
            ],
            "answer": 0,
            "why": "4Ch is DOS exit. AL is the code. syscall 60 is x86-64 Linux."
          },
          {
            "q": "Where does the exit code go?",
            "choices": [
              "AL",
              "CX",
              "x8",
              "rdi"
            ],
            "answer": 0,
            "why": "AL is the ERRORLEVEL. AH selects function 4Ch."
          },
          {
            "q": "Why is RET able to leave a .COM program?",
            "choices": [
              "Offset 0 of the PSP contains an INT 20h, and the stack points there",
              "RET executes syscall",
              "RET is a Win32 call",
              "The CPU resets"
            ],
            "answer": 0,
            "why": "DOS places INT 20h at the start of the PSP and a zero word on the stack."
          }
        ]
      },
      {
        "id": "dos-5",
        "title": "COM versus EXE",
        "teach": "A .COM file is a raw memory image, no header, at most one segment of code and data together. An MZ .EXE has a header, can have a separate stack, and can be larger than 64KB. Windows 95 still runs both inside a DOS virtual machine. A Win32 program is neither of those: it is a Portable Executable, loaded by the Windows loader in protected mode. Use COM or MZ when you are writing DOS. Use PE when you are writing Win32.",
        "code": "; COM: org 100h, no header\n; EXE: MZ header, SS:SP from the header\n; Win32: PE, WinMain",
        "questions": [
          {
            "q": "Which file is a raw image with ORG 100h and no header?",
            "choices": [
              ".COM",
              "PE",
              "ELF",
              "MZ with a relocation table"
            ],
            "answer": 0,
            "why": "COM files have no header. MZ and PE both do."
          },
          {
            "q": "What does Windows 95 use for a 32-bit GUI program?",
            "choices": [
              "A PE",
              "Only a .COM",
              "An ELF",
              "A Linux syscall table"
            ],
            "answer": 0,
            "why": "Win32 binaries are Portable Executables, even on Windows 95."
          },
          {
            "q": "Where does Windows 95 still run an INT 21h program?",
            "choices": [
              "In a DOS virtual machine",
              "Inside kernel32 as a normal Win32 thread with no VM",
              "By converting it to svc #0",
              "It cannot run DOS programs at all"
            ],
            "answer": 0,
            "why": "DOS programs keep the INT 21h interface inside a virtual 8086 session. Win32 programs do not."
          }
        ]
      },
      {
        "id": "dos-6",
        "title": "Windows 95 Win32",
        "teach": "A Windows 95 GUI or console Win32 program starts at WinMain, not at ORG 100h. User32 and kernel32 are DLL imports. MessageBox and ExitProcess use stdcall: push arguments right to left, and the callee cleans the stack. MessageBox(NULL, text, caption, MB_OK) pushes MB_OK first and the HWND last. ExitProcess does not return. GetLastError, not the carry flag, reports Win32 failures. The DOS AH=4Ch exit is for DOS programs only.",
        "code": "push MB_OK\npush offset caption\npush offset text\npush 0\ncall MessageBoxA\npush 0\ncall ExitProcess",
        "questions": [
          {
            "q": "Which convention does 32-bit MessageBox use?",
            "choices": [
              "stdcall",
              "Linux syscall with rax",
              "ecall with a7",
              "AH=09h"
            ],
            "answer": 0,
            "why": "32-bit Win32 exports are stdcall. The callee removes the four dword arguments."
          },
          {
            "q": "In the snippet, what is pushed immediately before call MessageBoxA?",
            "choices": [
              "The HWND, which is 0",
              "MB_OK",
              "The DOS function number",
              "x8"
            ],
            "answer": 0,
            "why": "Right-to-left pushes leave the first argument, hWnd, next to the call."
          },
          {
            "q": "How does this Win32 program end?",
            "choices": [
              "call ExitProcess",
              "int 21h with AH=4Ch",
              "syscall",
              "RET to the PSP"
            ],
            "answer": 0,
            "why": "ExitProcess is the Win32 exit. AH=4Ch is the DOS exit used by COM programs."
          }
        ]
      }
    ]
  }
];
