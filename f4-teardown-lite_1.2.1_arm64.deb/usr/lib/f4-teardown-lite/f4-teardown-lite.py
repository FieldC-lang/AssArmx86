#!/usr/bin/python3
"""F4 Teardown for Linux (lite).

One GTK window running the simulator in WebKitGTK, the web engine most Linux desktops already have. It is the
counterpart of MainActivity.java and the Electron shell in ../../desktop.

The simulator files are served from f4app://f4teardown/, a custom scheme that never touches the network, so the
app is fully offline and localStorage has a stable origin. The HTML carries a Content-Security-Policy that blocks
every other request, and links to the manuals open in the default browser.
"""

import json
import os
import sys
import time

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
try:
    gi.require_version("WebKit2", "4.1")
    gi.require_version("Soup", "3.0")
except ValueError:
    gi.require_version("WebKit2", "4.0")
    gi.require_version("Soup", "2.4")
from gi.repository import Gdk, Gio, GLib, Gtk, Soup, WebKit2  # noqa: E402

APP_ID = "com.f4teardown.sim"
APP_NAME = "F4 Teardown"
SCHEME = "f4app"
HOST = "f4teardown"
ORIGIN = f"{SCHEME}://{HOST}/"
START_URL = ORIGIN + "index.html"
DIR_NAME = "f4-teardown-lite"

HERE = os.path.dirname(os.path.realpath(__file__))
WEB_ROOT = os.path.realpath(
    os.environ.get("F4_WEB_ROOT")
    or next((p for p in (os.path.join(HERE, "web"), os.path.join(HERE, "..", "..", "android", "app", "src", "main", "assets"))
             if os.path.isdir(p)), os.path.join(HERE, "web"))
)
DEVTOOLS = os.environ.get("F4_DEVTOOLS") == "1"

# The page's --bg colour, light and dark.
BG_LIGHT, BG_DARK = "#E9EEF1", "#0C1114"

CSP = "; ".join([
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",
    "media-src 'self' data: blob:",
    "connect-src 'self'",
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'none'",
])

MIME = {
    "html": "text/html", "js": "text/javascript", "css": "text/css", "json": "application/json",
    "txt": "text/plain", "svg": "image/svg+xml", "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
    "webp": "image/webp", "gif": "image/gif", "ico": "image/x-icon", "woff": "font/woff", "woff2": "font/woff2",
    "ttf": "font/ttf", "otf": "font/otf", "mp3": "audio/mpeg", "ogg": "audio/ogg", "wav": "audio/wav",
    "wasm": "application/wasm",
}

BRIDGE_JS = """(function () {
  var night = %s, post = function (m) { try { window.webkit.messageHandlers.f4.postMessage(m); } catch (e) { } };
  window.F4App = {
    isNight: function () { return night; },
    onTheme: function (dark, pref) { post("theme|" + (dark ? 1 : 0) + "|" + pref); },
    setCanGoBack: function (can) { post("back|" + (can ? 1 : 0)); }
  };
  window.__f4SetNight = function (n) { night = !!n; if (window.__f4SysNight) window.__f4SysNight(); };
})();"""


def xdg_dir(env, fallback):
    return os.path.join(os.environ.get(env) or os.path.expanduser(fallback), DIR_NAME)


SETTINGS_FILE = os.path.join(xdg_dir("XDG_CONFIG_HOME", "~/.config"), "settings.json")


def load_settings():
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            s = json.load(f)
        return s if isinstance(s, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(settings):
    try:
        os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
        tmp = SETTINGS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=2)
        os.replace(tmp, SETTINGS_FILE)
    except OSError:
        pass  # not fatal: the career save lives in the page's localStorage, not here


def rgba(hex_colour):
    c = Gdk.RGBA()
    c.parse(hex_colour)
    return c


class SystemTheme:
    """Desktop dark-mode preference, from the freedesktop settings portal or, failing that, the GTK theme name."""

    def __init__(self, on_change):
        self.on_change = on_change
        self.proxy = None
        name = (Gtk.Settings.get_default().props.gtk_theme_name or "").lower()
        self.dark = name.endswith("-dark") or ":dark" in name
        try:
            self.proxy = Gio.DBusProxy.new_for_bus_sync(
                Gio.BusType.SESSION, Gio.DBusProxyFlags.DO_NOT_AUTO_START, None, "org.freedesktop.portal.Desktop",
                "/org/freedesktop/portal/desktop", "org.freedesktop.portal.Settings", None)
            value = self.proxy.call_sync("Read", GLib.Variant("(ss)", ("org.freedesktop.appearance", "color-scheme")),
                                         Gio.DBusCallFlags.NONE, 1000, None).unpack()[0]
            while isinstance(value, GLib.Variant):
                value = value.unpack()
            if value in (1, 2):
                self.dark = value == 1
            self.proxy.connect("g-signal", self._on_signal)
        except GLib.Error:
            self.proxy = None

    def _on_signal(self, _proxy, _sender, signal, params):
        if signal != "SettingChanged":
            return
        namespace, key, value = params.unpack()
        if (namespace, key) != ("org.freedesktop.appearance", "color-scheme"):
            return
        while isinstance(value, GLib.Variant):
            value = value.unpack()
        dark = value == 1
        if dark != self.dark:
            self.dark = dark
            self.on_change()


class F4Window(Gtk.ApplicationWindow):
    def __init__(self, app, settings):
        super().__init__(application=app, title=APP_NAME)
        self.settings = settings
        self.can_go_back = False
        self.fullscreen_on = False
        self.maximized = False
        self.deaths = 0
        self.first_death_at = 0.0
        self.system = SystemTheme(self._on_system_theme)
        theme = settings.get("theme")
        # Start in the colours the page will use: its saved choice, else the desktop setting.
        self.page_dark = theme == "dark" or (theme != "light" and self.system.dark)

        self.set_default_size(max(760, int(settings.get("width", 1400))), max(520, int(settings.get("height", 880))))
        self.set_size_request(760, 520)
        if settings.get("maximized"):
            self.maximize()

        self.web = self._create_webview()
        self.add(self.web)
        self._apply_theme(self.page_dark)

        self.connect("key-press-event", self._on_key)
        self.connect("window-state-event", self._on_window_state)
        self.connect("delete-event", self._on_close)
        self.web.load_uri(START_URL)

    # ---------------- web view ----------------

    def _create_webview(self):
        manager = WebKit2.WebsiteDataManager(base_data_directory=xdg_dir("XDG_DATA_HOME", "~/.local/share"),
                                             base_cache_directory=xdg_dir("XDG_CACHE_HOME", "~/.cache"))
        context = WebKit2.WebContext(website_data_manager=manager)
        context.set_cache_model(WebKit2.CacheModel.DOCUMENT_VIEWER)
        context.register_uri_scheme(SCHEME, self._serve)
        security = context.get_security_manager()
        security.register_uri_scheme_as_secure(SCHEME)
        security.register_uri_scheme_as_cors_enabled(SCHEME)

        self.content = WebKit2.UserContentManager()
        self.content.register_script_message_handler("f4")
        self.content.connect("script-message-received::f4", self._on_message)
        self._install_bridge()

        web = WebKit2.WebView(web_context=context, user_content_manager=self.content)
        s = web.get_settings()
        s.set_enable_developer_extras(DEVTOOLS)
        s.set_enable_write_console_messages_to_stdout(DEVTOOLS)
        s.set_javascript_can_open_windows_automatically(False)
        s.set_javascript_can_access_clipboard(True)   # Save code -> Copy
        s.set_media_playback_requires_user_gesture(True)
        s.set_enable_back_forward_navigation_gestures(False)
        s.set_enable_webgl(True)

        web.connect("decide-policy", self._on_policy)
        web.connect("create", lambda *_: None)
        web.connect("permission-request", self._on_permission)
        web.connect("context-menu", lambda *_: not DEVTOOLS)
        web.connect("web-process-terminated", self._on_web_process_gone)
        web.connect("button-press-event", self._on_button)
        web.connect("load-changed", self._on_load_changed)
        return web

    def _serve(self, request):
        path = request.get_path() or ""
        rel = GLib.uri_unescape_string(path, None) or ""
        rel = rel.lstrip("/")
        target = os.path.realpath(os.path.join(WEB_ROOT, rel))
        if request.get_uri().split("/")[2:3] != [HOST] or not rel or not target.startswith(WEB_ROOT + os.sep):
            request.finish_error(GLib.Error.new_literal(Gio.io_error_quark(), "Not Found", Gio.IOErrorEnum.NOT_FOUND))
            return
        try:
            with open(target, "rb") as f:
                data = f.read()
        except OSError:
            request.finish_error(GLib.Error.new_literal(Gio.io_error_quark(), "Not Found", Gio.IOErrorEnum.NOT_FOUND))
            return
        ext = target.rsplit(".", 1)[-1].lower()
        mime = MIME.get(ext, "application/octet-stream")
        stream = Gio.MemoryInputStream.new_from_bytes(GLib.Bytes.new(data))
        if hasattr(WebKit2, "URISchemeResponse"):
            response = WebKit2.URISchemeResponse.new(stream, len(data))
            response.set_content_type(mime + ("; charset=utf-8" if mime.startswith("text/") else ""))
            headers = Soup.MessageHeaders.new(Soup.MessageHeadersType.RESPONSE)
            headers.append("Cache-Control", "no-cache")
            if ext == "html":
                headers.append("Content-Security-Policy", CSP)
            response.set_http_headers(headers)
            request.finish_with_response(response)
        else:
            request.finish(stream, len(data), mime)

    @staticmethod
    def _is_app_url(uri):
        return (uri or "").startswith(ORIGIN)

    def _open_externally(self, uri):
        if not uri or uri.split(":", 1)[0].lower() not in ("http", "https", "mailto"):
            return
        try:
            Gtk.show_uri_on_window(self, uri, Gdk.CURRENT_TIME)
        except GLib.Error:
            self._message(Gtk.MessageType.INFO, "No app is installed that can open this link.", uri)

    def _on_policy(self, _web, decision, kind):
        if kind not in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            return False
        uri = decision.get_navigation_action().get_request().get_uri()
        if kind == WebKit2.PolicyDecisionType.NAVIGATION_ACTION and self._is_app_url(uri):
            return False
        decision.ignore()
        self._open_externally(uri)
        return True

    @staticmethod
    def _on_permission(_web, request):
        request.deny()
        return True

    def _on_load_changed(self, _web, event):
        if event == WebKit2.LoadEvent.STARTED:
            self.can_go_back = False

    def _on_web_process_gone(self, _web, reason):
        now = time.monotonic()
        if now - self.first_death_at > 60:
            self.first_death_at = now
            self.deaths = 0
        self.can_go_back = False
        self.deaths += 1
        if self.deaths >= 3:   # don't loop forever on a machine that can't keep the page alive
            self._message(Gtk.MessageType.ERROR, "The 3D view closed unexpectedly several times.",
                          "This computer may be short of memory or its graphics driver may have stopped responding. "
                          "Close other apps, then open F4 Teardown again.")
            self.get_application().quit()
            return
        self.web.reload()

    # ---------------- page <-> app bridge (window.F4App, as MainActivity provides) ----------------

    def _install_bridge(self):
        self.content.remove_all_scripts()
        self.content.add_script(WebKit2.UserScript.new(
            BRIDGE_JS % ("true" if self.system.dark else "false"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
            WebKit2.UserScriptInjectionTime.START, None, None))

    def _run_js(self, js):
        if hasattr(self.web, "evaluate_javascript"):
            self.web.evaluate_javascript(js, -1, None, None, None, None, None)
        else:
            self.web.run_javascript(js, None, None, None)

    def _on_message(self, _manager, result):
        value = result.get_js_value() if hasattr(result, "get_js_value") else result
        msg = value.to_string() if value is not None else ""
        if msg.startswith("theme|") and len(msg) >= 8:
            pref = msg[8:]
            self._apply_theme(msg[6] == "1")
            if pref in ("auto", "light", "dark") and self.settings.get("theme") != pref:
                self.settings["theme"] = pref
                save_settings(self.settings)
        elif msg.startswith("back|") and len(msg) >= 6:
            self.can_go_back = msg[5] == "1"

    def _on_system_theme(self):
        self._install_bridge()   # so a reload starts with the new value
        self._run_js("window.__f4SetNight&&window.__f4SetNight(%s)" % ("true" if self.system.dark else "false"))

    def _apply_theme(self, dark):
        self.page_dark = dark
        # Title bar / window decorations follow the page's theme.
        Gtk.Settings.get_default().props.gtk_application_prefer_dark_theme = dark
        self.web.set_background_color(rgba(BG_DARK if dark else BG_LIGHT))

    def _web_back(self):
        if self.can_go_back:
            self._run_js("window.__f4Back&&window.__f4Back()")

    # ---------------- window ----------------

    def _on_button(self, _web, event):
        if event.button == 8:   # mouse "back" button: what Android's Back does inside the page
            self._web_back()
            return True
        return False

    def _on_key(self, _win, event):
        ctrl = bool(event.state & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(event.state & Gdk.ModifierType.SHIFT_MASK)
        key = event.keyval
        if key == Gdk.KEY_F11:
            self.unfullscreen() if self.fullscreen_on else self.fullscreen()
        elif key == Gdk.KEY_Back:
            self._web_back()
        elif ctrl and key in (Gdk.KEY_plus, Gdk.KEY_equal, Gdk.KEY_KP_Add):
            self.web.set_zoom_level(min(self.web.get_zoom_level() + 0.1, 3.0))
        elif ctrl and key in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
            self.web.set_zoom_level(max(self.web.get_zoom_level() - 0.1, 0.3))
        elif ctrl and key in (Gdk.KEY_0, Gdk.KEY_KP_0):
            self.web.set_zoom_level(1.0)
        elif ctrl and not shift and key in (Gdk.KEY_q, Gdk.KEY_Q):
            self.close()
        elif DEVTOOLS and (key == Gdk.KEY_F12 or (ctrl and shift and key in (Gdk.KEY_i, Gdk.KEY_I))):
            self.web.get_inspector().show()
        else:
            return False
        return True

    def _on_window_state(self, _win, event):
        state = event.new_window_state
        self.fullscreen_on = bool(state & Gdk.WindowState.FULLSCREEN)
        self.maximized = bool(state & Gdk.WindowState.MAXIMIZED)
        # Nothing should be heard while the window is out of sight.
        if hasattr(self.web, "set_is_muted"):
            self.web.set_is_muted(bool(state & Gdk.WindowState.ICONIFIED))
        return False

    def _on_close(self, *_):
        if not self.maximized and not self.fullscreen_on:
            w, h = self.get_size()
            self.settings["width"], self.settings["height"] = w, h
        self.settings["maximized"] = self.maximized
        save_settings(self.settings)
        return False

    def _message(self, kind, text, detail):
        dialog = Gtk.MessageDialog(transient_for=self, modal=True, message_type=kind, buttons=Gtk.ButtonsType.OK,
                                   text=text, secondary_text=detail)
        dialog.run()
        dialog.destroy()


class F4App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window = None

    def do_activate(self):
        # A second launch lands here in the running instance.
        if self.window is None:
            self.window = F4Window(self, load_settings())
            self.window.show_all()
        self.window.present()


def main():
    if not os.path.isfile(os.path.join(WEB_ROOT, "index.html")):
        sys.exit(f"f4-teardown-lite: simulator files not found in {WEB_ROOT}")
    GLib.set_prgname(APP_ID)
    GLib.set_application_name(APP_NAME)
    Gtk.Window.set_default_icon_name(APP_ID)
    return F4App().run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
