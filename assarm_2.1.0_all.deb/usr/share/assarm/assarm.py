#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
AssArm - a desktop window for the ARMv7 assembly course.

The course itself is one self-contained HTML file. This launcher puts it in a
real application window with a full-screen mode, and keeps its saved progress
in the user's own data directory rather than in a browser profile.

If WebKitGTK is not available it does not fail: it hands the page to a browser
in application mode instead, so the course always opens.
"""

import os
import sys
import shutil
import subprocess

APP_ID = "org.assarm.AssArm"
APP_NAME = "AssArm"
VERSION = "2.1.0"

# Where the course lives once installed, with a source-tree fallback so the
# same script runs from a checkout.
CANDIDATE_PAGES = [
    "/usr/share/assarm/assarm.html",
    "/usr/local/share/assarm/assarm.html",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "assarm.html"),
]


def find_page():
    for p in CANDIDATE_PAGES:
        if os.path.isfile(p):
            return p
    return None


def data_dir():
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return os.path.join(base, "assarm")


def cache_dir():
    base = os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache")
    return os.path.join(base, "assarm")


# --------------------------------------------------------------------------
# Fallback: no WebKitGTK on this machine, so use whatever browser there is.
# --------------------------------------------------------------------------

def run_in_browser(page, fullscreen=False):
    url = "file://" + page
    app_browsers = [
        "chromium", "chromium-browser", "google-chrome", "google-chrome-stable",
        "brave-browser", "microsoft-edge", "vivaldi",
    ]
    for name in app_browsers:
        exe = shutil.which(name)
        if exe:
            args = [exe, "--app=" + url, "--class=AssArm",
                    "--user-data-dir=" + os.path.join(cache_dir(), "browser")]
            if fullscreen:
                args.append("--start-fullscreen")
            try:
                os.makedirs(cache_dir(), exist_ok=True)
                subprocess.Popen(args)
                return True
            except OSError:
                pass
    for name in ("firefox", "epiphany-browser", "xdg-open"):
        exe = shutil.which(name)
        if exe:
            try:
                subprocess.Popen([exe, url])
                return True
            except OSError:
                pass
    return False


def no_webkit_message():
    sys.stderr.write(
        APP_NAME + ": WebKitGTK is not installed, and no browser was found either.\n"
        "Install one of these and try again:\n"
        "    sudo apt install gir1.2-webkit2-4.1\n"
        "  (on older releases: sudo apt install gir1.2-webkit2-4.0)\n"
        "The course is a single file and can also be opened by hand:\n"
        "    xdg-open /usr/share/assarm/assarm.html\n"
    )


# --------------------------------------------------------------------------
# The real window.
# --------------------------------------------------------------------------

def load_gtk_webkit():
    """Return (Gtk, WebKit2, GLib) or None. WebKitGTK is spelled several
    different ways across distributions, so try each in turn."""
    try:
        import gi
    except ImportError:
        return None
    try:
        gi.require_version("Gtk", "3.0")
    except ValueError:
        return None
    for namespace, version in (("WebKit2", "4.1"), ("WebKit2", "4.0"), ("WebKit2", "5.0")):
        try:
            gi.require_version(namespace, version)
            from gi.repository import Gtk, GLib
            webkit = __import__("gi.repository." + namespace, fromlist=[namespace])
            return Gtk, webkit, GLib
        except (ValueError, ImportError):
            continue
    return None


def build_window(page, start_fullscreen, selftest=False):
    loaded = load_gtk_webkit()
    if loaded is None:
        return None
    Gtk, WebKit2, GLib = loaded

    os.makedirs(data_dir(), exist_ok=True)
    os.makedirs(cache_dir(), exist_ok=True)

    # Keep localStorage (the course's saved progress) under ~/.local/share/assarm
    # so it survives upgrades and is not mixed in with any browser profile.
    try:
        manager = WebKit2.WebsiteDataManager(
            base_data_directory=data_dir(),
            base_cache_directory=cache_dir(),
        )
        context = WebKit2.WebContext.new_with_website_data_manager(manager)
    except Exception:
        context = WebKit2.WebContext.get_default()

    try:
        view = WebKit2.WebView.new_with_context(context)
    except Exception:
        view = WebKit2.WebView()

    settings = view.get_settings()
    settings.set_enable_developer_extras(True)
    settings.set_enable_write_console_messages_to_stdout(False)
    for setter, value in (
        ("set_enable_page_cache", True),
        ("set_enable_smooth_scrolling", True),
        ("set_enable_back_forward_navigation_gestures", False),
        ("set_javascript_can_open_windows_automatically", False),
    ):
        if hasattr(settings, setter):
            try:
                getattr(settings, setter)(value)
            except Exception:
                pass

    window = Gtk.Window()
    window.set_title(APP_NAME)
    window.set_default_size(1180, 900)
    window.set_icon_name("assarm")
    # So that the desktop entry, the task bar and the window all agree on which
    # application this is, and it picks up the installed icon.
    try:
        GLib.set_prgname("assarm")
        GLib.set_application_name(APP_NAME)
        window.set_role("assarm")
    except Exception:
        pass

    state = {"fullscreen": False}

    header = Gtk.HeaderBar()
    header.set_show_close_button(True)
    header.set_title(APP_NAME)
    header.set_subtitle("ARMv7 · A32")

    fs_button = Gtk.Button()
    fs_button.set_tooltip_text("Full screen (F11)")
    fs_icon = Gtk.Image.new_from_icon_name("view-fullscreen-symbolic", Gtk.IconSize.BUTTON)
    fs_button.set_image(fs_icon)

    def set_fullscreen(on):
        state["fullscreen"] = bool(on)
        if on:
            window.fullscreen()
            fs_icon.set_from_icon_name("view-restore-symbolic", Gtk.IconSize.BUTTON)
            fs_button.set_tooltip_text("Leave full screen (F11 or Esc)")
            header.set_visible(False)
        else:
            window.unfullscreen()
            fs_icon.set_from_icon_name("view-fullscreen-symbolic", Gtk.IconSize.BUTTON)
            fs_button.set_tooltip_text("Full screen (F11)")
            header.set_visible(True)

    fs_button.connect("clicked", lambda _b: set_fullscreen(not state["fullscreen"]))
    header.pack_end(fs_button)

    def zoom(delta):
        level = view.get_zoom_level()
        if delta == 0:
            level = 1.0
        else:
            level = max(0.5, min(3.0, level + delta))
        view.set_zoom_level(level)

    zoom_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
    zoom_box.get_style_context().add_class("linked")
    for label, tip, delta in (("−", "Smaller text (Ctrl -)", -0.1),
                              ("+", "Larger text (Ctrl +)", 0.1)):
        b = Gtk.Button.new_with_label(label)
        b.set_tooltip_text(tip)
        b.connect("clicked", lambda _b, d=delta: zoom(d))
        zoom_box.pack_start(b, False, False, 0)
    header.pack_start(zoom_box)

    window.set_titlebar(header)
    scroller = Gtk.ScrolledWindow()
    scroller.add(view)
    window.add(scroller)

    # In full screen the header bar is hidden, so every way out has to be a key.
    def on_key(_w, event):
        from gi.repository import Gdk
        key = Gdk.keyval_name(event.keyval)
        ctrl = bool(event.state & Gdk.ModifierType.CONTROL_MASK)
        if key == "F11":
            set_fullscreen(not state["fullscreen"])
            return True
        if key == "Escape" and state["fullscreen"]:
            set_fullscreen(False)
            return True
        if key == "F5" or (ctrl and key in ("r", "R")):
            view.reload()
            return True
        if ctrl and key in ("plus", "equal", "KP_Add"):
            zoom(0.1)
            return True
        if ctrl and key in ("minus", "KP_Subtract"):
            zoom(-0.1)
            return True
        if ctrl and key in ("0", "KP_0"):
            zoom(0)
            return True
        if ctrl and key in ("q", "Q", "w", "W"):
            Gtk.main_quit()
            return True
        return False

    window.connect("key-press-event", on_key)
    window.connect("destroy", Gtk.main_quit)

    # Links to the outside world open in the user's browser, not in here.
    def on_decide(_view, decision, decision_type):
        try:
            if decision_type == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
                uri = decision.get_navigation_action().get_request().get_uri()
                if uri and not uri.startswith("file:") and not uri.startswith("about:"):
                    decision.ignore()
                    opener = shutil.which("xdg-open")
                    if opener:
                        subprocess.Popen([opener, uri])
                    return True
        except Exception:
            pass
        return False

    view.connect("decide-policy", on_decide)

    if selftest:
        install_selftest(Gtk, GLib, view)

    view.load_uri("file://" + page)

    window.show_all()
    if start_fullscreen:
        set_fullscreen(True)
    return Gtk


SELFTEST_JS = """(function () {
  var out = { units: 0, lessons: 0, storage: 'no', ran: 'no', title: document.title };
  try {
    out.units = document.querySelectorAll('.unit').length;
    out.lessons = document.querySelectorAll('.lrow').length;
  } catch (e) {}
  try {
    localStorage.setItem('assarm.selftest', 'yes');
    out.storage = localStorage.getItem('assarm.selftest') === 'yes' ? 'yes' : 'readback-failed';
    localStorage.removeItem('assarm.selftest');
  } catch (e) { out.storage = 'threw: ' + e.name; }
  try {
    var r = window.AssArmCore.runSource('mov r0, #42\\nadd r0, r0, #1');
    out.ran = (r.ok && r.machine.regs[0] === 43) ? 'yes' : 'wrong';
  } catch (e) { out.ran = 'threw: ' + e.message; }
  return JSON.stringify(out);
})();"""


def install_selftest(Gtk, GLib, view):
    """Load the page headlessly, prove the emulator and localStorage work, print
    the result and quit. Used when building the package, never by a user."""
    def finished(webview, result, _data=None):
        text = "(no result)"
        try:
            value = webview.run_javascript_finish(result)
            js = value.get_js_value()
            text = js.to_string()
        except Exception as exc:
            text = "selftest failed: " + str(exc)
        sys.stdout.write("SELFTEST " + text + "\n")
        sys.stdout.flush()
        Gtk.main_quit()

    def on_load(webview, event):
        if event == getattr(webview, "props", None) or str(event).endswith("FINISHED") or int(event) == 3:
            GLib.timeout_add(700, lambda: (webview.run_javascript(SELFTEST_JS, None, finished, None), False)[1])

    view.connect("load-changed", on_load)
    GLib.timeout_add_seconds(25, lambda: (sys.stdout.write("SELFTEST timeout\n"), Gtk.main_quit(), False)[2])


def main(argv):
    if "--version" in argv:
        print(APP_NAME + " " + VERSION)
        return 0
    if "--help" in argv or "-h" in argv:
        print("Usage: assarm [--fullscreen] [--browser] [--version]")
        print("  --fullscreen  start with the window already full screen")
        print("  --browser     skip the app window and open in the default browser")
        return 0

    page = find_page()
    if page is None:
        sys.stderr.write(APP_NAME + ": cannot find assarm.html. Is the package installed correctly?\n")
        return 1

    start_fullscreen = "--fullscreen" in argv or "-f" in argv

    if "--browser" in argv:
        return 0 if run_in_browser(page, start_fullscreen) else 1

    Gtk = build_window(page, start_fullscreen, selftest=("--selftest" in argv))
    if Gtk is None:
        if run_in_browser(page, start_fullscreen):
            sys.stderr.write(
                APP_NAME + ": WebKitGTK is not installed, so the course opened in your browser instead.\n"
                "For the application window: sudo apt install gir1.2-webkit2-4.1\n")
            return 0
        no_webkit_message()
        return 1

    Gtk.main()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
