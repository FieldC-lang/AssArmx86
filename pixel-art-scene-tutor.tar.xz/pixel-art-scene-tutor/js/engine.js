/* SceneForge painting engine */
(function () {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  let track = null;
  let L = null;
  let A = []; // layers: Int16Array-like number[] per layer, -1 empty
  let act = 0;
  let vis = [];
  let hist = [];
  let tool = "pen";
  let col = 2;
  let sqd = false;
  let dn = false;
  let lx = 0,
    ly = 0;
  let sx = 0,
    sy = 0;
  let base = null;
  let flags = { sqd: false, seenAnim: false };
  let P = { done: {}, work: {}, cur: 0 };
  let cur = 0;
  let animOn = true;
  let animPhase = 0;
  let animRaf = 0;
  let strokeDir = [1, 0];

  const cv = () => $("#c");
  const ctx = () => cv().getContext("2d");

  function W() {
    return track.W;
  }
  function H() {
    return track.H;
  }
  function pal(li) {
    const ramp = track.layerDefs[li].ramp;
    return track.ramps[ramp];
  }
  function emptyLayer() {
    return Array(W() * H()).fill(-1);
  }

  function loadProgress() {
    P = { done: {}, work: {}, cur: 0 };
    try {
      Object.assign(P, JSON.parse(localStorage.getItem(track.storage) || "{}"));
    } catch (e) {}
    P.done = P.done || {};
    P.work = P.work || {};
  }
  function saveProgress() {
    try {
      localStorage.setItem(track.storage, JSON.stringify(P));
    } catch (e) {}
  }

  function lessonLayers() {
    return L.layers.map((i) => track.layerDefs[i]);
  }

  function initLesson(i) {
    cur = i;
    L = track.lessons[i];
    P.cur = i;
    flags = { sqd: false, seenAnim: false };
    sqd = false;
    cv().classList.remove("gray");

    const saved = P.work[L.id];
    if (saved && saved.length === track.layerDefs.length) {
      A = saved.map((d) => d.slice());
    } else {
      A = track.layerDefs.map(() => emptyLayer());
      // soft-carry previous lesson art for same track if growing layers
      const prevId = track.lessons[i - 1] && track.lessons[i - 1].id;
      if (prevId && P.work[prevId]) {
        P.work[prevId].forEach((d, li) => {
          if (d && A[li]) A[li] = d.slice();
        });
      }
    }
    vis = track.layerDefs.map(() => true);
    act = L.layers.find((li) => true) ?? 0;
    // prefer first editable layer in lesson
    act = L.layers[0];
    hist = [];
    col = Math.min(col, pal(act).length - 1);
    tool = "pen";
    renderLessonUI();
    draw();
    check();
    saveProgress();
    head();
    chips();
  }

  function head() {
    const d = Object.keys(P.done).length;
    const n = track.lessons.length;
    $("#pt").textContent = `${d}/${n} lessons · ${d * 150} XP`;
    $("#pb").style.width = (d / n) * 100 + "%";
  }

  function chips() {
    $("#chips").innerHTML = track.lessons
      .map(
        (l, i) =>
          `<button type="button" class="chip${i === cur ? " on" : ""}${P.done[l.id] ? " d" : ""}" data-i="${i}">${l.id}. ${l.t}</button>`
      )
      .join("");
  }

  function renderLessonUI() {
    $("#lv").textContent = `${track.name} · Lesson ${L.id} / ${track.lessons.length}`;
    $("#lt").textContent = L.t;
    $("#ll").textContent = L.learn;
    $("#lp").textContent = L.tip;
    $("#ld").innerHTML = L.detail || "";
    $("#ob").innerHTML = L.obj.map(([t]) => `<li>${t}</li>`).join("");
    $("#win").hidden = true;

    // layers
    $("#ly").innerHTML = track.layerDefs
      .map((l, k) => {
        const inLesson = L.layers.includes(k);
        const locked = !inLesson;
        return `<span class="ly"><input type="checkbox" data-v="${k}" ${vis[k] ? "checked" : ""} aria-label="Show ${l.n}"><button type="button" class="chip${k === act ? " on" : ""}" data-l="${k}"${locked ? " disabled" : ""}>${l.n}${locked ? "" : ""}</button></span>`;
      })
      .join("");

    $("#pl").innerHTML = pal(act)
      .map(
        (c, i) =>
          `<button type="button" class="sw" data-i="${i}" style="background:${c}" aria-label="Colour ${i + 1}" aria-pressed="${i === col}"></button>`
      )
      .join("");

    $$("[data-t]").forEach((b) => b.setAttribute("aria-pressed", b.dataset.t === tool));
    $("#sq").setAttribute("aria-pressed", sqd ? "true" : "false");
    $("#an").setAttribute("aria-pressed", animOn ? "true" : "false");
  }

  function compositeColor(i, phase) {
    // bottom to top
    for (let k = 0; k < A.length; k++) {
      if (!vis[k]) continue;
      let idx = i;
      const y = (i / W()) | 0;
      const x = i % W();
      // animate weather / water / motes / petals by shifting sample
      const mode = L.anim;
      if (mode && A[k][i] >= 0) {
        const name = track.layerDefs[k].n.toLowerCase();
        if ((mode === "rain" || mode === "both" || mode === "petals") && name.includes("weather")) {
          const ox = (phase / 2) | 0;
          const oy = phase | 0;
          const nx = (x + ox) % W();
          const ny = (y + oy) % H();
          const v = A[k][ny * W() + nx];
          if (v >= 0) return shade(pal(k)[v], sqd);
          continue;
        }
        if ((mode === "water" || mode === "both") && name.includes("water")) {
          const ox = ((phase + y) % 4) - 1;
          const nx = Math.max(0, Math.min(W() - 1, x + ((x + phase) % 2 === 0 ? ox : 0)));
          const v = A[k][y * W() + nx];
          if (v >= 0) return shade(pal(k)[v], sqd);
          continue;
        }
        if (mode === "motes" && name.includes("magic")) {
          const pulse = (Math.sin((phase + x * 0.3 + y * 0.2) * 0.4) + 1) / 2;
          if (pulse < 0.35 && A[k][i] >= 3) continue; // twinkle off
        }
      }
      const v = A[k][idx];
      if (v >= 0) return shade(pal(k)[v], sqd);
    }
    return sqd ? "#6a6a6a" : ((xChecker(i) ? "#1a2233" : "#141a28"));
  }

  function xChecker(i) {
    const x = i % W(),
      y = (i / W()) | 0;
    return (x + y) % 2;
  }

  function shade(hex, gray) {
    if (!gray) return hex;
    const n = parseInt(hex.slice(1), 16);
    const r = (n >> 16) & 255,
      g = (n >> 8) & 255,
      b = n & 255;
    const y = (r * 0.3 + g * 0.59 + b * 0.11) | 0;
    return `rgb(${y},${y},${y})`;
  }

  function draw() {
    const c = ctx();
    const cw = cv().width,
      ch = cv().height;
    const sx = cw / W(),
      sy = ch / H();
    for (let i = 0; i < W() * H(); i++) {
      c.fillStyle = compositeColor(i, 0);
      c.fillRect((i % W()) * sx, ((i / W()) | 0) * sy, sx, sy);
    }
    // horizon guide
    c.strokeStyle = "rgba(255,200,80,.35)";
    c.setLineDash([6, 6]);
    c.beginPath();
    c.moveTo(0, (track.HZ + 0.5) * sy);
    c.lineTo(cw, (track.HZ + 0.5) * sy);
    c.stroke();
    c.setLineDash([]);
    previewStatic();
  }

  function blitTo(target, phase) {
    const p = target;
    const q = p.getContext("2d");
    p.width = W();
    p.height = H();
    const img = q.createImageData(W(), H());
    for (let i = 0; i < W() * H(); i++) {
      const hex = compositeColor(i, phase);
      let r, g, b;
      if (hex.startsWith("#")) {
        const n = parseInt(hex.slice(1), 16);
        r = (n >> 16) & 255;
        g = (n >> 8) & 255;
        b = n & 255;
      } else {
        const m = hex.match(/\d+/g);
        r = +m[0];
        g = +m[1];
        b = +m[2];
      }
      const o = i * 4;
      img.data[o] = r;
      img.data[o + 1] = g;
      img.data[o + 2] = b;
      img.data[o + 3] = 255;
    }
    q.putImageData(img, 0, 0);
  }

  function previewStatic() {
    blitTo($("#pv"), 0);
  }

  function animLoop() {
    if (!animOn) return;
    animPhase = (animPhase + 1) % 64;
    blitTo($("#av"), animPhase);
    flags.seenAnim = true;
    animRaf = requestAnimationFrame(() => {
      // throttle ~10fps
      setTimeout(() => animLoop(), 100);
    });
  }

  function startAnim() {
    cancelAnimationFrame(animRaf);
    if (animOn) animLoop();
    else blitTo($("#av"), 0);
  }

  function layerStats(d, np) {
    const c = Array(np).fill(0);
    const top = Array(W()).fill(-1);
    const cy = Array(np).fill(0);
    let f = 0;
    for (let i = 0; i < d.length; i++) {
      const v = d[i];
      if (v >= 0) {
        c[v]++;
        f++;
        cy[v] += (i / W()) | 0;
        const x = i % W();
        if (top[x] < 0) top[x] = (i / W()) | 0;
      }
    }
    return {
      c,
      f,
      top,
      u: c.filter(Boolean).length,
      my: cy.map((s, k) => (c[k] ? s / c[k] : null)),
    };
  }

  function check() {
    const Z = A.map((d, li) => layerStats(d, pal(li).length));
    const ok = L.obj.map(([, fn]) => {
      try {
        return !!fn(Z, A, flags);
      } catch (e) {
        return false;
      }
    });
    $$("#ob li").forEach((li, i) => li.classList.toggle("ok", ok[i]));
    const all = ok.every(Boolean);
    $("#win").hidden = !all;
    if (all && !P.done[L.id]) {
      P.done[L.id] = 1;
      saveProgress();
      head();
      chips();
    }
    if (all) {
      const nx = $("#nx");
      if (cur < track.lessons.length - 1) {
        nx.textContent = "Next lesson →";
        nx.onclick = () => initLesson(cur + 1);
      } else {
        nx.textContent = "Track complete — back to hub";
        nx.onclick = () => window.SceneForge.showHub();
      }
    }
  }

  function snap() {
    hist.push(A.map((d) => d.slice()));
    if (hist.length > 50) hist.shift();
  }
  function persist() {
    P.work[L.id] = A.map((d) => d.slice());
    saveProgress();
  }
  function undo() {
    if (!hist.length) return;
    A = hist.pop();
    draw();
    check();
    persist();
    startAnim();
  }

  function pos(e) {
    const r = cv().getBoundingClientRect();
    const t = e.touches ? e.touches[0] : e;
    const x = Math.floor(((t.clientX - r.left) / r.width) * W());
    const y = Math.floor(((t.clientY - r.top) / r.height) * H());
    return [Math.max(0, Math.min(W() - 1, x)), Math.max(0, Math.min(H() - 1, y))];
  }

  function setPx(x, y, v) {
    if (!L.layers.includes(act)) return;
    A[act][y * W() + x] = v;
  }

  function flood(x, y, v) {
    const d = A[act];
    const target = d[y * W() + x];
    if (target === v) return;
    const q = [[x, y]];
    const seen = new Uint8Array(W() * H());
    while (q.length) {
      const [cx, cy] = q.pop();
      const i = cy * W() + cx;
      if (seen[i]) continue;
      seen[i] = 1;
      if (d[i] !== target) continue;
      d[i] = v;
      if (cx > 0) q.push([cx - 1, cy]);
      if (cx < W() - 1) q.push([cx + 1, cy]);
      if (cy > 0) q.push([cx, cy - 1]);
      if (cy < H() - 1) q.push([cx, cy + 1]);
    }
  }

  function ditherAt(x, y) {
    if ((x + y) % 2 === 0) setPx(x, y, col);
  }

  function strokeAt(x, y) {
    const [dx, dy] = strokeDir;
    for (let k = 0; k < 3; k++) {
      const xx = x + dx * k,
        yy = y + dy * k;
      if (xx >= 0 && yy >= 0 && xx < W() && yy < H()) {
        const tone = Math.max(0, Math.min(pal(act).length - 1, col + (k === 2 ? (col < 4 ? 1 : -1) : 0)));
        setPx(xx, yy, tool === "erase" ? -1 : tone);
      }
    }
  }

  function paint(x, y, first) {
    if (tool === "pen") setPx(x, y, col);
    else if (tool === "erase") setPx(x, y, -1);
    else if (tool === "dither") ditherAt(x, y);
    else if (tool === "stroke") {
      if (!first) {
        const adx = x - lx,
          ady = y - ly;
        if (Math.abs(adx) + Math.abs(ady) > 0) {
          strokeDir = [Math.sign(adx) || 0, Math.sign(ady) || 0];
          if (!strokeDir[0] && !strokeDir[1]) strokeDir = [1, 0];
        }
      }
      strokeAt(x, y);
    } else if (tool === "pick") {
      const v = A[act][y * W() + x];
      if (v >= 0) {
        col = v;
        renderLessonUI();
      }
    }
  }

  function onDown(e) {
    e.preventDefault();
    if (!L.layers.includes(act)) return;
    dn = true;
    const [x, y] = pos(e);
    lx = x;
    ly = y;
    sx = x;
    sy = y;
    if (tool === "rect") {
      base = A[act].slice();
    } else if (tool === "fill") {
      snap();
      flood(x, y, col);
      draw();
      check();
      persist();
      startAnim();
      dn = false;
      return;
    } else {
      snap();
      paint(x, y, true);
      draw();
    }
  }
  function onMove(e) {
    if (!dn) return;
    e.preventDefault();
    const [x, y] = pos(e);
    if (tool === "rect") {
      A[act] = base.slice();
      const x0 = Math.min(sx, x),
        x1 = Math.max(sx, x);
      const y0 = Math.min(sy, y),
        y1 = Math.max(sy, y);
      for (let yy = y0; yy <= y1; yy++) for (let xx = x0; xx <= x1; xx++) setPx(xx, yy, col);
      draw();
    } else {
      // bresenham-ish
      let x0 = lx,
        y0 = ly;
      const dx = Math.abs(x - x0),
        dy = Math.abs(y - y0);
      const sx_ = x0 < x ? 1 : -1,
        sy_ = y0 < y ? 1 : -1;
      let err = dx - dy;
      while (true) {
        paint(x0, y0, false);
        if (x0 === x && y0 === y) break;
        const e2 = 2 * err;
        if (e2 > -dy) {
          err -= dy;
          x0 += sx_;
        }
        if (e2 < dx) {
          err += dx;
          y0 += sy_;
        }
      }
      draw();
    }
    lx = x;
    ly = y;
  }
  function onUp() {
    if (!dn) return;
    dn = false;
    base = null;
    check();
    persist();
    startAnim();
  }

  function clearLayer() {
    if (!L.layers.includes(act)) return;
    snap();
    A[act] = emptyLayer();
    draw();
    check();
    persist();
    startAnim();
  }

  function exampleScene() {
    snap();
    // procedural starter per track — helps learners see target density
    const id = track.id;
    A = track.layerDefs.map(() => emptyLayer());
    if (id === "cyberpunk") genCyber();
    else if (id === "medieval") genMedieval();
    else genJapanese();
    draw();
    check();
    persist();
    startAnim();
  }

  function genCyber() {
    // sky bands
    for (let y = 0; y < H(); y++) {
      const t = Math.min(4, (y / track.HZ) * 4.2) | 0;
      for (let x = 0; x < W(); x++) A[0][y * W() + x] = Math.max(0, Math.min(4, t + ((x + y) % 2 && y > 10 ? 1 : 0) - (y < 4 ? 1 : 0)));
    }
    // far city
    for (let x = 0; x < W(); x++) {
      const h = 18 + ((Math.sin(x * 0.35) * 6 + Math.sin(x * 0.11) * 4) | 0);
      for (let y = h; y < 40; y++) A[1][y * W() + x] = y === h ? 3 : 1 + (y % 3 === 0 ? 1 : 0);
    }
    // neon
    for (let n = 0; n < 14; n++) {
      const x = 4 + n * 6 + (n % 3);
      const y0 = 20 + (n % 5);
      for (let y = y0; y < y0 + 8; y++) {
        A[2][y * W() + x] = n % 2 ? 4 : 3;
        if (x + 1 < W()) A[2][y * W() + x + 1] = n % 2 ? 2 : 1;
      }
    }
    // water
    for (let y = 38; y < H(); y++)
      for (let x = 0; x < W(); x++) {
        const ry = Math.min(H() - 1, Math.max(0, ((y - 38) * 0.7 + 22) | 0));
        const refl = A[2][ry * W() + x];
        A[3][y * W() + x] = refl >= 3 ? 3 : 1 + ((x + y) % 2);
      }
    // rain
    for (let i = 0; i < 160; i++) {
      const x = (Math.random() * W()) | 0;
      const y = (Math.random() * 40) | 0;
      A[4][y * W() + x] = 3;
      if (y + 1 < H() && x + 1 < W()) A[4][(y + 1) * W() + x + 1] = 2;
    }
    // fg
    for (let y = 48; y < H(); y++) for (let x = 0; x < W(); x++) A[5][y * W() + x] = y === 48 ? 2 : 0;
    for (let x of [8, 20, 70, 85]) for (let y = 44; y < 50; y++) A[5][y * W() + x] = 1;
  }

  function genMedieval() {
    for (let y = 0; y < H(); y++) {
      const t = Math.min(4, (y / 28) * 4) | 0;
      for (let x = 0; x < W(); x++) A[0][y * W() + x] = t;
    }
    for (let x = 0; x < W(); x++) {
      const h = 20 + ((Math.sin(x * 0.2) * 3) | 0);
      for (let y = h; y < 32; y++) A[1][y * W() + x] = 2;
    }
    // castle
    for (let y = 14; y < 40; y++)
      for (let x = 38; x < 62; x++) {
        A[2][y * W() + x] = 2;
      }
    for (let t = 0; t < 3; t++) {
      const tx = 40 + t * 8;
      for (let y = 8; y < 18; y++) for (let x = tx; x < tx + 5; x++) A[2][y * W() + x] = 3;
      A[2][12 * W() + tx + 2] = 0;
    }
    for (let x = 0; x < W(); x++) {
      const h = 32 + ((Math.sin(x * 0.4) * 2) | 0);
      for (let y = h; y < 46; y++) A[3][y * W() + x] = y === h ? 3 : 1;
    }
    for (let i = 0; i < 40; i++) {
      const x = 20 + ((Math.random() * 50) | 0);
      const y = 18 + ((Math.random() * 20) | 0);
      A[4][y * W() + x] = 4;
      for (const [a, b] of [
        [0, 1],
        [1, 0],
        [-1, 0],
        [0, -1],
      ]) {
        const xx = x + a,
          yy = y + b;
        if (xx >= 0 && yy >= 0 && xx < W() && yy < H() && A[4][yy * W() + xx] < 0) A[4][yy * W() + xx] = 2;
      }
    }
    for (let y = 46; y < H(); y++) for (let x = 0; x < W(); x++) A[5][y * W() + x] = 1;
  }

  function genJapanese() {
    for (let y = 0; y < H(); y++) {
      const t = Math.min(4, (y / 28) * 4.5) | 0;
      for (let x = 0; x < W(); x++) A[0][y * W() + x] = t;
    }
    for (let x = 10; x < 50; x++) {
      const h = 22 + ((((x - 30) * (x - 30)) / 80) | 0);
      for (let y = h; y < 34; y++) A[1][y * W() + x] = 2;
    }
    // torii
    for (let y = 20; y < 42; y++) {
      A[2][y * W() + 58] = 2;
      A[2][y * W() + 74] = 2;
    }
    for (let x = 54; x < 79; x++) {
      A[2][18 * W() + x] = 3;
      A[2][22 * W() + x] = 2;
    }
    for (let x = 0; x < 40; x++) {
      const h = 28 + ((Math.sin(x * 0.5) * 3) | 0);
      for (let y = h; y < 44; y++) A[3][y * W() + x] = y === h ? 3 : 1;
    }
    for (let i = 0; i < 25; i++) {
      const x = 5 + ((Math.random() * 35) | 0);
      const y = 26 + ((Math.random() * 10) | 0);
      A[3][y * W() + x] = 4;
    }
    for (let y = 40; y < H() - 4; y++)
      for (let x = 0; x < W(); x++) A[4][y * W() + x] = 1 + ((x + y + ((y / 2) | 0)) % 2);
    for (let i = 0; i < 100; i++) {
      const x = (Math.random() * W()) | 0;
      const y = (Math.random() * 38) | 0;
      A[5][y * W() + x] = 3;
    }
    for (let y = 50; y < H(); y++) for (let x = 0; x < W(); x++) A[6][y * W() + x] = 1;
  }

  function bind() {
    const c = cv();
    c.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    c.addEventListener("contextmenu", (e) => e.preventDefault());

    $("#chips").addEventListener("click", (e) => {
      const b = e.target.closest("[data-i]");
      if (b) initLesson(+b.dataset.i);
    });
    $("#ly").addEventListener("click", (e) => {
      const b = e.target.closest("[data-l]");
      if (b && !b.disabled) {
        act = +b.dataset.l;
        col = Math.min(col, pal(act).length - 1);
        renderLessonUI();
      }
    });
    $("#ly").addEventListener("change", (e) => {
      const inp = e.target.closest("[data-v]");
      if (inp) {
        vis[+inp.dataset.v] = inp.checked;
        draw();
        startAnim();
      }
    });
    $("#pl").addEventListener("click", (e) => {
      const b = e.target.closest("[data-i]");
      if (b) {
        col = +b.dataset.i;
        renderLessonUI();
      }
    });
    $("#tl").addEventListener("click", (e) => {
      const b = e.target.closest("[data-t]");
      if (b) {
        tool = b.dataset.t;
        renderLessonUI();
      }
    });
    $("#un").onclick = undo;
    $("#cl").onclick = clearLayer;
    $("#ex").onclick = exampleScene;
    $("#sq").onclick = () => {
      sqd = !sqd;
      flags.sqd = flags.sqd || sqd;
      cv().classList.toggle("gray", sqd);
      $("#sq").setAttribute("aria-pressed", sqd ? "true" : "false");
      draw();
      check();
      startAnim();
    };
    $("#an").onclick = () => {
      animOn = !animOn;
      flags.seenAnim = true;
      $("#an").setAttribute("aria-pressed", animOn ? "true" : "false");
      startAnim();
      check();
    };
    $("#back").onclick = () => window.SceneForge.showHub();
  }

  window.SceneForge = {
    startTrack(id) {
      track = window.SceneTracks[id];
      if (!track) return;
      document.documentElement.style.setProperty("--track", track.accent);
      loadProgress();
      $("#hub").hidden = true;
      $("#app").hidden = false;
      $("#trackName").textContent = track.name;
      cur = Math.min(+P.cur || 0, track.lessons.length - 1);
      // size canvas backing store for crisp pixels
      const c = cv();
      c.width = track.W * 10;
      c.height = track.H * 10;
      initLesson(cur);
      startAnim();
    },
    showHub() {
      $("#app").hidden = true;
      $("#hub").hidden = false;
      cancelAnimationFrame(animRaf);
    },
    bind,
  };
})();
