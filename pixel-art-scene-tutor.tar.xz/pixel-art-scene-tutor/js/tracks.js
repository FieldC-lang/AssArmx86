/* SceneForge lesson tracks — higher-res scene training */
window.SceneTracks = {
  cyberpunk: {
    id: "cyberpunk",
    name: "Cyberpunk Neon",
    tagline: "Rain-soaked megacity nights: neon, wet streets, canals, and weather.",
    accent: "#39d0ff",
    W: 96,
    H: 54,
    HZ: 30,
    storage: "sceneforge-cyber-v1",
    lessons: null, // filled below
  },
  medieval: {
    id: "medieval",
    name: "Medieval Magical",
    tagline: "Castles at dusk, enchanted forests, rune-glow, and floating motes.",
    accent: "#c9a0ff",
    W: 96,
    H: 54,
    HZ: 28,
    storage: "sceneforge-medieval-v1",
    lessons: null,
  },
  japanese: {
    id: "japanese",
    name: "Japanese Scene",
    tagline: "Ukiyo-e skies, temples, lanterns, blossom, and seasonal weather.",
    accent: "#ff6b7a",
    W: 96,
    H: 54,
    HZ: 28,
    storage: "sceneforge-japanese-v1",
    lessons: null,
  },
};

(function () {
  const C = window.SceneTracks.cyberpunk;
  const M = window.SceneTracks.medieval;
  const J = window.SceneTracks.japanese;

  // Palette ramps: each is 5 tones dark→light. Index = ramp*5 + tone.
  C.ramps = [
    ["#050816", "#0d1a3a", "#1a3a6e", "#3d6fb0", "#9ec9ff"], // night sky
    ["#120018", "#3a0066", "#7a00cc", "#c44dff", "#f0b0ff"], // magenta neon
    ["#001820", "#003844", "#006e7a", "#00c8d4", "#a8ffff"], // cyan neon
    ["#0a0e14", "#1c2838", "#3a5068", "#6a849c", "#b8c8d8"], // concrete / haze
    ["#021018", "#0a3040", "#145868", "#2a8898", "#70c8d8"], // water
    ["#1a0800", "#5a2000", "#c04800", "#ff9020", "#ffe08a"], // amber / sodium
    ["#04060a", "#101820", "#203040", "#405060", "#8090a0"], // near dark FG
  ];
  C.layerDefs = [
    { n: "Sky", ramp: 0 },
    { n: "Far city", ramp: 3 },
    { n: "Neon mid", ramp: 1 },
    { n: "Water", ramp: 4 },
    { n: "Weather", ramp: 2 },
    { n: "Foreground", ramp: 6 },
  ];

  M.ramps = [
    ["#1a1028", "#3a2858", "#6a4890", "#b088d0", "#f0d8ff"], // dusk / magic sky
    ["#0e1820", "#243848", "#486878", "#88a8b0", "#d0e0e8"], // cool mist
    ["#1a1208", "#3a2810", "#6a4820", "#a87838", "#e8c888"], // stone / earth
    ["#081808", "#183018", "#386038", "#68a058", "#b8e090"], // forest
    ["#200818", "#581030", "#a02058", "#e05090", "#ffb0d0"], // rune rose
    ["#201000", "#583000", "#a06010", "#e0a030", "#ffe090"], // gold glow
    ["#0a1008", "#182818", "#304830", "#507050", "#90b090"], // near trees
  ];
  M.layerDefs = [
    { n: "Sky", ramp: 0 },
    { n: "Far peaks", ramp: 1 },
    { n: "Castle", ramp: 2 },
    { n: "Forest", ramp: 3 },
    { n: "Magic FX", ramp: 4 },
    { n: "Foreground", ramp: 6 },
  ];

  J.ramps = [
    ["#1a2038", "#3a4870", "#7080a8", "#c0b0c8", "#f8e0d0"], // evening sky
    ["#101828", "#283848", "#506878", "#90a8b0", "#d8e8e8"], // distant haze
    ["#201010", "#482828", "#784848", "#b08070", "#e8c8b0"], // wood / roof
    ["#201018", "#582030", "#a03848", "#e07080", "#ffc0c8"], // cherry / lantern
    ["#081820", "#183848", "#386878", "#68a0b0", "#b0dce8"], // water
    ["#182010", "#384828", "#688048", "#a0b868", "#d8e8a8"], // pine / moss
    ["#100c08", "#2a2018", "#4a3830", "#706058", "#a89888"], // near dark
  ];
  J.layerDefs = [
    { n: "Sky", ramp: 0 },
    { n: "Far land", ramp: 1 },
    { n: "Architecture", ramp: 2 },
    { n: "Nature", ramp: 5 },
    { n: "Water", ramp: 4 },
    { n: "Weather", ramp: 3 },
    { n: "Foreground", ramp: 6 },
  ];

  /* ---------- helpers used inside objective closures (bound at runtime by engine) ---------- */
  // Lesson factories receive a ctx API from the engine via lesson.obj checkers that
  // close over nothing — engine passes Z, D, anim, flags. We define lessons with
  // functions (Z, D, flags) => bool

  function fillPct(Z, li, min) {
    return Z[li] && Z[li].f >= min;
  }
  function usesTones(Z, li, n) {
    return Z[li] && Z[li].u >= n;
  }
  function darkestOnTop(Z, li) {
    const m = Z[li].my;
    const used = m.map((v, i) => (v !== null ? i : -1)).filter((i) => i >= 0);
    if (used.length < 2) return false;
    return m[used[0]] < m[used[used.length - 1]];
  }

  C.lessons = [
    {
      id: 1,
      t: "Night sky architecture",
      layers: [0],
      learn:
        "Cyberpunk nights start with a deep value stack: near-black zenith, cobalt mid-sky, and a polluted glow near the horizon from city light bounce. At 96×54 you have room for 5–6 sky bands instead of 3–4 — use them to sell atmosphere before any buildings exist.",
      tip: "On the Sky layer, block bands with Rectangle from darkest (top) to lighter cyan-blue near the horizon line. Keep the bottom ~40% of the sky on the two lightest blues.",
      detail:
        "<b>Why:</b> Players read the horizon glow as “city exists below” even before silhouettes. <b>Avoid:</b> flat single-tone skies — they kill depth.",
      anim: null,
      obj: [
        ["Fill 95%+ of the Sky layer", (Z) => Z[0].f >= 0.95 * 96 * 54],
        ["Use 4+ sky tones", (Z) => usesTones(Z, 0, 4)],
        ["Darker sky at top, lighter near horizon", (Z) => darkestOnTop(Z, 0)],
        [
          "Horizon glow: 180+ pixels of the two lightest sky tones in the lower sky (rows 18–30)",
          (Z, D) => {
            const d = D[0];
            let n = 0;
            for (let y = 18; y < 30; y++)
              for (let x = 0; x < 96; x++) {
                const v = d[y * 96 + x];
                if (v >= 3) n++;
              }
            return n >= 180;
          },
        ],
      ],
    },
    {
      id: 2,
      t: "Far megacity haze",
      layers: [0, 1],
      learn:
        "Distant towers should be lighter and closer to the sky colour (atmospheric perspective). At this resolution, far buildings are simple stepped silhouettes — no windows yet. Leave gaps for neon later.",
      tip: "Paint Far city as a jagged skyline below the mid-sky. Rim the tops with one tone lighter than the mass so towers catch horizon light.",
      detail:
        "<b>Readability:</b> far layer should still silhouette when you Squint. <b>Seam tip:</b> vary tower heights; avoid a flat roof line.",
      anim: null,
      obj: [
        ["Far city: 900+ pixels", (Z) => fillPct(Z, 1, 900)],
        ["Far city uses 3+ tones", (Z) => usesTones(Z, 1, 3)],
        [
          "Skyline variation: 10+ different roof heights",
          (Z) => new Set(Z[1].top.filter((t) => t >= 0)).size >= 10,
        ],
        [
          "Far ridge sits in the middle third of the canvas",
          (Z) => {
            const tops = Z[1].top.filter((t) => t >= 0);
            if (!tops.length) return false;
            const avg = tops.reduce((a, b) => a + b, 0) / tops.length;
            return avg >= 16 && avg <= 34;
          },
        ],
      ],
    },
    {
      id: 3,
      t: "Neon complementary punch",
      layers: [0, 1, 2],
      learn:
        "Neon sells cyberpunk when magenta and cyan fight each other. Place complementary colours as thin vertical signs and window strips — sparse accents beat flood-filling entire buildings.",
      tip: "On Neon mid, drop thin magenta and cyan columns (1–3 px wide) against darker concrete. Add a few amber sodium lights for warmth.",
      detail:
        "<b>Rule:</b> neon reads best when surrounded by dark. <b>Count:</b> aim for clusters, not noise — 8–20 sign strokes.",
      anim: null,
      obj: [
        ["Neon mid: 120+ magenta-ramp pixels (tones on neon layer using magenta palette)", (Z, D) => {
          // neon mid uses ramp 1 in layerDefs — palette indices are tone 0-4 of that layer's pal
          return Z[2].f >= 120;
        }],
        ["Use 3+ neon tones on Neon mid", (Z) => usesTones(Z, 2, 3)],
        [
          "Bright accents: 40+ pixels of the two lightest neon tones",
          (Z) => (Z[2].c[3] || 0) + (Z[2].c[4] || 0) >= 40,
        ],
        [
          "Keep neon sparse: under 18% of the canvas on Neon mid",
          (Z) => Z[2].f > 0 && Z[2].f <= 0.18 * 96 * 54,
        ],
      ],
    },
    {
      id: 4,
      t: "Wet street reflections",
      layers: [0, 1, 2, 3],
      learn:
        "Rain-soaked asphalt mirrors neon as vertical smears. Reflections are darker and broken — dither and shorten them. Water lives on its own layer so you can animate ripple phase later.",
      tip: "Paint a dark water/road band in the lower third. Under each neon cluster, drag vertical reflections with Dither using one tone darker than the neon.",
      detail:
        "<b>Physics cheat:</b> reflections stretch down, not sideways. <b>Value:</b> reflected neon should never outshine the source.",
      anim: "water",
      obj: [
        ["Water layer: 700+ pixels", (Z) => fillPct(Z, 3, 700)],
        ["Water uses 3+ tones", (Z) => usesTones(Z, 3, 3)],
        [
          "Water occupies the lower canvas (avg row ≥ 36)",
          (Z) => Z[3].my.every((v, i) => Z[3].c[i] === 0 || v === null || v >= 34),
        ],
        [
          "Dithered reflection texture: 40+ checkerboard water pixels",
          (Z, D) => ditherCount(D[3], 96, 54) >= 40,
        ],
      ],
    },
    {
      id: 5,
      t: "Canal water animation",
      layers: [0, 1, 2, 3],
      learn:
        "Animated water in pixel art is usually a looping dither phase or a 2–4 frame highlight crawl — not fluid sim. SceneForge’s Anim preview shifts water dither over time. Paint horizontal ripple bands so the phase shift reads as flow.",
      tip: "Add 2–3 horizontal bands of alternating water tones. Put brightest water highlights in short dashes. Watch the Anim preview.",
      detail:
        "<b>Loop length:</b> 8–16 frames is enough. <b>Hold:</b> large flat water with no band structure won’t animate well.",
      anim: "water",
      obj: [
        ["Water: 900+ pixels", (Z) => fillPct(Z, 3, 900)],
        [
          "Ripple bands: water present across 20+ columns in rows 40–48",
          (Z, D) => {
            let cols = 0;
            for (let x = 0; x < 96; x++) {
              let hit = false;
              for (let y = 40; y < 48; y++) if (D[3][y * 96 + x] >= 0) hit = true;
              if (hit) cols++;
            }
            return cols >= 20;
          },
        ],
        [
          "Highlight dashes: 50+ lightest water tone pixels",
          (Z) => (Z[3].c[4] || 0) >= 50,
        ],
        ["Confirm you opened Anim preview (press Anim once)", (_, __, f) => !!f.seenAnim],
      ],
    },
    {
      id: 6,
      t: "Rain weather layer",
      layers: [0, 1, 2, 3, 4],
      learn:
        "Rain is a sparse overlay of slanted 1–2 px streaks on its own Weather layer. Animate by scrolling the layer diagonally in the Anim preview. Density matters: too many streaks become fog.",
      tip: "With Weather active, sprinkle cyan/light streaks sloping down-right. Leave big empty gaps. Keep streaks off the brightest neon so signs still pop.",
      detail:
        "<b>Density target:</b> ~1–3% of pixels. <b>Direction:</b> pick one wind angle and stick to it.",
      anim: "rain",
      obj: [
        [
          "Weather layer sparse: 80–350 pixels",
          (Z) => Z[4].f >= 80 && Z[4].f <= 350,
        ],
        ["Weather uses 2+ tones", (Z) => usesTones(Z, 4, 2)],
        [
          "Streaks lean: more weather pixels with empty below-right neighbour than below-left",
          (Z, D) => {
            const d = D[4];
            let r = 0,
              l = 0;
            for (let y = 0; y < 53; y++)
              for (let x = 0; x < 96; x++) {
                const i = y * 96 + x;
                if (d[i] < 0) continue;
                if (x < 95 && d[i + 97] < 0) r++;
                if (x > 0 && d[i + 95] < 0) l++;
              }
            return r > l + 10;
          },
        ],
        ["Confirm Anim preview for rain", (_, __, f) => !!f.seenAnim],
      ],
    },
    {
      id: 7,
      t: "Foreground framing",
      layers: [0, 1, 2, 3, 4, 5],
      learn:
        "A dark foreground parapet, cable, or railing grounds the camera and adds parallax. Keep it simple and mostly silhouette — detail belongs mid-scene.",
      tip: "Paint a dark strip along the bottom and a few vertical posts or pipes. Use only the darker tones.",
      detail: "<b>Squint test:</b> FG should be the darkest mass; sky the lightest mid-band.",
      anim: "rain",
      obj: [
        ["Foreground: 500+ pixels", (Z) => fillPct(Z, 5, 500)],
        [
          "FG sits low: 90%+ of FG pixels in bottom 14 rows",
          (Z, D) => {
            const d = D[5];
            let all = 0,
              low = 0;
            for (let i = 0; i < d.length; i++) {
              if (d[i] < 0) continue;
              all++;
              if ((i / 96) | 0 >= 40) low++;
            }
            return all >= 500 && low / all >= 0.9;
          },
        ],
        ["FG uses 2+ tones but stays dark (avg tone ≤ 1.5)", (Z) => {
          if (!usesTones(Z, 5, 2)) return false;
          let s = 0,
            n = 0;
          Z[5].c.forEach((c, t) => {
            s += c * t;
            n += c;
          });
          return n && s / n <= 1.5;
        }],
      ],
    },
    {
      id: 8,
      t: "Full scene polish",
      layers: [0, 1, 2, 3, 4, 5],
      learn:
        "Bring every layer to a readable stack: sky → far haze → neon → water → weather → FG. Squint for value; Anim for weather/water motion. One bright focal neon cluster should dominate.",
      tip: "Fix any layer that disappears in Squint. Boost one focal neon area. Re-check Anim rain + water.",
      detail: "<b>Ship checklist:</b> values, complementary neon, sparse rain, looping water, dark FG frame.",
      anim: "both",
      obj: [
        ["Every layer has 60+ pixels", (Z) => Z.every((z) => z.f >= 60)],
        ["Neon mid still sparse (<20% canvas)", (Z) => Z[2].f <= 0.2 * 96 * 54],
        ["Squint check performed", (_, __, f) => !!f.sqd],
        ["Anim preview watched", (_, __, f) => !!f.seenAnim],
      ],
    },
  ];

  M.lessons = [
    {
      id: 1,
      t: "Magic-hour sky",
      layers: [0],
      learn:
        "Medieval fantasy skies often sit at dusk: violet zenith, rose mid, pale gold near the horizon. That complementary cool/warm split makes towers and forests read as silhouettes later.",
      tip: "Band the Sky from deep violet (top) to pale lilac/gold near the horizon. Soften band edges with Dither.",
      detail: "<b>Mood:</b> dusk implies lanterns and magic will glow later. Midday green forests fight purple castles.",
      anim: null,
      obj: [
        ["Sky 95%+ filled", (Z) => Z[0].f >= 0.95 * 96 * 54],
        ["4+ sky tones", (Z) => usesTones(Z, 0, 4)],
        ["Dark top → light horizon", (Z) => darkestOnTop(Z, 0)],
        ["Dithered sky transitions: 50+ pixels", (Z, D) => ditherCount(D[0], 96, 54) >= 50],
      ],
    },
    {
      id: 2,
      t: "Distant peaks & mist",
      layers: [0, 1],
      learn:
        "Far mountains should be misty and low-contrast — almost sky-coloured. Soft scalloped ridges beat jagged noise at distance.",
      tip: "Paint Far peaks as pale cool silhouettes. Leave the ridge lighter than the mass beneath.",
      detail: "<b>Atmospheric perspective:</b> each further layer loses saturation and contrast.",
      anim: null,
      obj: [
        ["Far peaks: 800+ pixels", (Z) => fillPct(Z, 1, 800)],
        ["3+ peak tones", (Z) => usesTones(Z, 1, 3)],
        ["8+ ridge heights", (Z) => new Set(Z[1].top.filter((t) => t >= 0)).size >= 8],
      ],
    },
    {
      id: 3,
      t: "Castle silhouette",
      layers: [0, 1, 2],
      learn:
        "The castle is a midground hero shape: keepers, towers, and a gate suggestion. At 96×54, imply architecture with stepped blocks — don’t draw every brick.",
      tip: "Build Castle with warm stone. Add 2–3 towers of different heights and a few window slit pixels in a darker tone.",
      detail: "<b>Readable icon:</b> the castle should still parse at 25% size in the preview.",
      anim: null,
      obj: [
        ["Castle: 600+ pixels", (Z) => fillPct(Z, 2, 600)],
        ["3+ stone tones", (Z) => usesTones(Z, 2, 3)],
        [
          "Tall silhouette: towers reach row 22 or above, mass continues below row 36",
          (Z, D) => {
            const d = D[2];
            let minY = 99,
              low = false;
            for (let i = 0; i < d.length; i++) {
              if (d[i] < 0) continue;
              const y = (i / 96) | 0;
              minY = Math.min(minY, y);
              if (y >= 36) low = true;
            }
            return minY <= 22 && low;
          },
        ],
        [
          "Dark window slits: 12+ darkest castle tone pixels",
          (Z) => (Z[2].c[0] || 0) >= 12,
        ],
      ],
    },
    {
      id: 4,
      t: "Enchanted forest belt",
      layers: [0, 1, 2, 3],
      learn:
        "A forest belt in front of the castle adds depth and hides the castle base. Tree masses are dark green blobs with a few lighter leaf rims — not stick trunks.",
      tip: "Paint overlapping canopy humps on Forest. Keep gaps so the castle peeks through.",
      detail: "<b>Overlap:</b> forest should cover lower castle stones but not the towers.",
      anim: null,
      obj: [
        ["Forest: 700+ pixels", (Z) => fillPct(Z, 3, 700)],
        ["3+ forest tones", (Z) => usesTones(Z, 3, 3)],
        [
          "Forest sits lower than castle crown",
          (Z) => {
            const ct = Z[2].top.filter((t) => t >= 0);
            const ft = Z[3].top.filter((t) => t >= 0);
            if (!ct.length || !ft.length) return false;
            const ca = ct.reduce((a, b) => a + b, 0) / ct.length;
            const fa = ft.reduce((a, b) => a + b, 0) / ft.length;
            return fa > ca + 2;
          },
        ],
      ],
    },
    {
      id: 5,
      t: "Rune glow & magic FX",
      layers: [0, 1, 2, 3, 4],
      learn:
        "Magic reads as coloured light that ignores naturalistic shading: rose/gold blooms, particle motes, and soft halos. Put FX on Magic FX so Anim can twinkle them.",
      tip: "Place a few bright rose or gold clusters near windows or forest gaps. Surround cores with one darker halo tone.",
      detail: "<b>Anim:</b> motes will pulse opacity in the preview — sparse beats dense glitter.",
      anim: "motes",
      obj: [
        ["Magic FX: 60–280 pixels (keep it special)", (Z) => Z[4].f >= 60 && Z[4].f <= 280],
        ["Bright cores: 20+ lightest FX tone", (Z) => (Z[4].c[4] || 0) >= 20],
        ["2+ FX tones for halo", (Z) => usesTones(Z, 4, 2)],
        ["Watched Anim motes", (_, __, f) => !!f.seenAnim],
      ],
    },
    {
      id: 6,
      t: "Grounding foreground",
      layers: [0, 1, 2, 3, 4, 5],
      learn:
        "Dark grass, rocks, or a path in the foreground lock the camera. Keep detail low; let magic and castle stay the focus.",
      tip: "Add a dark FG strip and a couple of rock/tree silhouettes rising into the forest.",
      detail: "<b>Squint:</b> FG darkest, sky lightest mid, castle mid-warm.",
      anim: "motes",
      obj: [
        ["Foreground: 450+ pixels", (Z) => fillPct(Z, 5, 450)],
        [
          "Mostly bottom: 85%+ FG in bottom 12 rows",
          (Z, D) => {
            let a = 0,
              b = 0;
            D[5].forEach((v, i) => {
              if (v < 0) return;
              a++;
              if ((i / 96) | 0 >= 42) b++;
            });
            return a >= 450 && b / a >= 0.85;
          },
        ],
        ["Squint performed", (_, __, f) => !!f.sqd],
      ],
    },
    {
      id: 7,
      t: "Legend complete",
      layers: [0, 1, 2, 3, 4, 5],
      learn:
        "Final pass: every layer contributes, magic twinkles, values separate. One golden or rose focal glow should lead the eye to the castle.",
      tip: "Balance FX so it accents the castle, not the whole sky. Confirm Anim + Squint.",
      detail: "<b>Done when:</b> story reads in 1 second — dusk, keep, forest, spell.",
      anim: "motes",
      obj: [
        ["All layers ≥ 50 pixels", (Z) => Z.every((z) => z.f >= 50)],
        ["Anim watched", (_, __, f) => !!f.seenAnim],
        ["Squint watched", (_, __, f) => !!f.sqd],
      ],
    },
  ];

  J.lessons = [
    {
      id: 1,
      t: "Ukiyo-e sky bands",
      layers: [0],
      learn:
        "Japanese scene skies often use clear horizontal bands — indigo, mauve, peach — inspired by woodblock prints. Soft dither between bands; keep the horizon warm.",
      tip: "Block 4–5 horizontal bands. Peach/pink near the horizon, deep blue above.",
      detail: "<b>Composition:</b> leave calm sky space for later moon or birds.",
      anim: null,
      obj: [
        ["Sky filled 95%+", (Z) => Z[0].f >= 0.95 * 96 * 54],
        ["4+ tones", (Z) => usesTones(Z, 0, 4)],
        ["Dark→light downward", (Z) => darkestOnTop(Z, 0)],
        ["Dither blends: 40+", (Z, D) => ditherCount(D[0], 96, 54) >= 40],
      ],
    },
    {
      id: 2,
      t: "Distant land & mist",
      layers: [0, 1],
      learn:
        "Far hills or shoreline stay pale and simplified. Suggest a mountain or island with a soft triangular mass.",
      tip: "Paint Far land as a gentle ridge using cool grey-blues.",
      detail: "<b>Negative space:</b> don’t fill the whole width — leave sky gaps.",
      anim: null,
      obj: [
        ["Far land: 700+ px", (Z) => fillPct(Z, 1, 700)],
        ["3+ tones", (Z) => usesTones(Z, 1, 3)],
        ["6+ ridge heights", (Z) => new Set(Z[1].top.filter((t) => t >= 0)).size >= 6],
      ],
    },
    {
      id: 3,
      t: "Temple or torii structure",
      layers: [0, 1, 2],
      learn:
        "Architecture is iconic: curved roof, pillars, or a torii gate. Use warm wood tones. At this res, silhouette clarity beats ornament.",
      tip: "Build a temple roof (wide trapezoid) or torii (two posts + two beams). Add a few darker beam lines.",
      detail: "<b>Icon test:</b> shape should read without colour.",
      anim: null,
      obj: [
        ["Architecture: 400+ px", (Z) => fillPct(Z, 2, 400)],
        ["3+ wood tones", (Z) => usesTones(Z, 2, 3)],
        [
          "Vertical posts: 2+ columns with 8+ stacked pixels",
          (Z, D) => {
            const d = D[2];
            let posts = 0;
            for (let x = 0; x < 96; x++) {
              let run = 0,
                best = 0;
              for (let y = 0; y < 54; y++) {
                if (d[y * 96 + x] >= 0) {
                  run++;
                  best = Math.max(best, run);
                } else run = 0;
              }
              if (best >= 8) posts++;
            }
            return posts >= 2;
          },
        ],
      ],
    },
    {
      id: 4,
      t: "Pine & blossom nature",
      layers: [0, 1, 2, 3],
      learn:
        "Nature layers carry seasonal identity: pine greens for calm evenings, cherry pink accents for spring. Place trees to frame architecture, not hide it.",
      tip: "Add pine masses on Nature. Sprinkle blossom pink on tips or as falling petal clusters.",
      detail: "<b>Asymmetry:</b> Japanese compositions often balance a heavy left with open right (or vice versa).",
      anim: null,
      obj: [
        ["Nature: 500+ px", (Z) => fillPct(Z, 3, 500)],
        ["3+ nature tones", (Z) => usesTones(Z, 3, 3)],
        [
          "Asymmetric mass: left third and right third differ by 80+ pixels",
          (Z, D) => {
            let L = 0,
              R = 0;
            D[3].forEach((v, i) => {
              if (v < 0) return;
              const x = i % 96;
              if (x < 32) L++;
              if (x >= 64) R++;
            });
            return Math.abs(L - R) >= 80;
          },
        ],
      ],
    },
    {
      id: 5,
      t: "Reflecting water",
      layers: [0, 1, 2, 3, 4],
      learn:
        "Ponds and shores mirror warm sky bands. Keep reflections softer and slightly darker; break them with horizontal ripple dither for Anim water phase.",
      tip: "Fill lower Water with cool tones. Mirror a bit of architecture colour downward in broken columns.",
      detail: "<b>Anim:</b> horizontal dither bands make the phase shift read as gentle ripples.",
      anim: "water",
      obj: [
        ["Water: 650+ px", (Z) => fillPct(Z, 4, 650)],
        ["3+ water tones", (Z) => usesTones(Z, 4, 3)],
        ["Water dither: 35+", (Z, D) => ditherCount(D[4], 96, 54) >= 35],
        ["Anim preview seen", (_, __, f) => !!f.seenAnim],
      ],
    },
    {
      id: 6,
      t: "Seasonal weather",
      layers: [0, 1, 2, 3, 4, 5],
      learn:
        "Sakura petals or rain/snow live on Weather. Petals are soft 2–4 px clusters that drift; rain is slanted streaks. Anim scrolls this layer slowly.",
      tip: "Scatter sparse blossom or rain on Weather. Prefer gaps over carpet coverage.",
      detail: "<b>Density:</b> 70–280 pixels feels seasonal, not stormy.",
      anim: "petals",
      obj: [
        ["Weather: 70–280 px", (Z) => Z[5].f >= 70 && Z[5].f <= 280],
        ["2+ weather tones", (Z) => usesTones(Z, 5, 2)],
        ["Anim seen", (_, __, f) => !!f.seenAnim],
      ],
    },
    {
      id: 7,
      t: "Ma & foreground",
      layers: [0, 1, 2, 3, 4, 5, 6],
      learn:
        "Ma (negative space) is part of the design — don’t overfill. A quiet dark foreground branch or stone anchors the scene while sky remains breathable.",
      tip: "Add a restrained FG element. Squint; protect empty sky. Confirm Anim weather + water.",
      detail: "<b>Finish:</b> calm sky, clear icon architecture, living weather.",
      anim: "both",
      obj: [
        ["FG: 300+ px", (Z) => fillPct(Z, 6, 300)],
        [
          "Protect ma: ≥ 8 columns in the top 12 rows without architecture or nature",
          (Z, D) => {
            let emptyCols = 0;
            for (let x = 0; x < 96; x++) {
              let skyOnly = true;
              for (let y = 0; y < 12; y++) {
                if (D[2][y * 96 + x] >= 0 || D[3][y * 96 + x] >= 0) skyOnly = false;
              }
              if (skyOnly) emptyCols++;
            }
            return emptyCols >= 8;
          },
        ],
        ["Squint + Anim both used", (_, __, f) => !!f.sqd && !!f.seenAnim],
      ],
    },
  ];

  function ditherCount(d, W, H) {
    let n = 0;
    for (let y = 1; y < H - 1; y++)
      for (let x = 1; x < W - 1; x++) {
        const i = y * W + x,
          v = d[i],
          w = d[i - 1];
        if (v >= 0 && w >= 0 && w !== v && d[i + 1] === w && d[i - W] === w && d[i + W] === w) n++;
      }
    return n;
  }
  // expose for any external debug
  window._ditherCount = ditherCount;
})();
