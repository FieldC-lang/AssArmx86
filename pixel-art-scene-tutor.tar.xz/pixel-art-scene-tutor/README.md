# SceneForge — Pixel Art Scene Tutor

A high-resolution, layered pixel-scene tutor inspired by **Swirl**, **Backdrop**, **Handcraft**, and **PixelPath**, with deeper lessons and animated weather/water previews.

## Open

```bash
# from this folder
xdg-open index.html
# or serve locally
python3 -m http.server 8765
# then visit http://localhost:8765
```

## Tracks

| Track | Focus | Animation |
| --- | --- | --- |
| **Cyberpunk Neon** | Sky glow, far city haze, magenta/cyan neon, wet reflections, canals, rain, FG framing | Rain scroll + water ripple phase |
| **Medieval Magical** | Magic-hour sky, misty peaks, castle, forest belt, rune glow, FG | Twinkling magic motes |
| **Japanese Scene** | Ukiyo-e bands, far land, torii/temple, pine & blossom, water, seasonal weather, ma | Petals/rain + water |

## Canvas

- Resolution: **96×54** (~2× Backdrop’s 48×27 / Swirl’s 64×40)
- Display: large pixelated canvas + still preview + **Anim** preview
- Tools: Pencil, Stroke, Dither, Rectangle, Fill, Pick, Eraser, Undo, Squint, Example scene

## Progress

Saved in `localStorage` per track (`sceneforge-cyber-v1`, `sceneforge-medieval-v1`, `sceneforge-japanese-v1`). Layers carry between lessons.

## Files

- `index.html` — hub + studio UI  
- `css/tutor.css` — layout and theme  
- `js/tracks.js` — palettes, layers, lesson objectives  
- `js/engine.js` — painting, checks, animation  
